# DS Copilot — prototipo 5

Plugin de Figma que lee tus pantallas, te muestra el design system implícito y lo convierte en fundaciones reales: Variables de color (claro y oscuro), tipografía, espaciado, radios y Text Styles. Claude propone, reglas fijas en código validan, vos aprobás, el plugin construye en Figma y verifica que haya quedado igual a lo aprobado.

## Instalar (Figma desktop)

1. Descomprimí la carpeta `ds-diagnostico` (si tenías la versión anterior, reemplazala).
2. **Plugins → Development → Import plugin from manifest…** y elegí `manifest.json`. Si ya lo habías importado, alcanza con volver a abrirlo.
3. Necesitás una API key de Anthropic (console.anthropic.com) con algo de crédito.

## Al abrirlo

La pantalla inicial dice si el archivo **ya tiene un design system** (cuántas Variables, colecciones, Text Styles y componentes) o si **todavía no hay uno**, y ofrece lo que corresponde:

- **Sin sistema:** analizá tus pantallas y armamos el sistema a partir de lo que ya diseñaste.
- **Con sistema creado por este plugin:** Crear componentes → y Crear o actualizar documentación →.
- **Con un sistema propio (otras colecciones):** Crear o actualizar documentación →.

Para analizar, elegí el alcance: **la selección** (aparece cuando hay capas seleccionadas), **esta página** o **todo el archivo**.

## Flujo para probar

1. Abrí el plugin en tu archivo con pantallas y analizá.
2. **Armar mi sistema a partir de esto** → pegá tu API key.
3. Creá un archivo nuevo, abrí el plugin ahí: debería retomar solo con el diagnóstico guardado. (Para ir rápido, también podés **Probar en este mismo archivo**.)
4. Color → Tipografía → Espacio: revisá cada propuesta, pedí cambios en lenguaje natural, aprobá.
5. Construir: se crean las colecciones `Primitives` y `Semantic`, los Text Styles y una página «Fundaciones». Después ves el checklist de verificación.

## Componentes (nuevo)

Después de construir las fundaciones, tocá **Crear componentes** (o abrí el plugin en el archivo de tu DS y usá **Crear componentes →** en la pantalla inicial).

1. **Botón:** estilos (Primary, Secondary…), tamaños S/M/L y estados normal, hover y deshabilitado.
2. **Campos:** una especificación para Input, Select y Textarea, con estados normal, foco, error y deshabilitado.
3. **Selección:** Checkbox y Radio, marcados y sin marcar.
4. **Construir:** crea los component sets en la página «Componentes», todos atados a tus semánticos, espaciados, radios y Text Styles, más un formulario de ejemplo en claro y oscuro. Después verifica variante por variante.

Si la IA necesita un rol que tu sistema no tiene (por ejemplo, un borde de campo que cumpla 3:1), lo propone como token nuevo y lo ves antes de aprobar. Si volvés a construir, reemplaza los componentes que el plugin creó antes.

## Componentes por conversación (nuevo)

Para crear cualquier componente que no sea botón, campos o selección: tooltip, toast, alert, stepper, badge, tabs, card…

1. En la pantalla inicial, cuando el archivo ya tiene un sistema: **Crear un componente conversando →** (también desde la pantalla de componentes).
2. Contá qué necesitás con tus palabras. Claude lo diseña usando solo los tokens de tu sistema.
3. Las reglas lo revisan antes de mostrártelo: que todo use tokens, contraste AA en claro y oscuro de cada variante, grilla de 4, nombres. Si encuentran problemas, Claude los corrige solo (hasta dos veces).
4. Ves todas las variantes en claro y oscuro, sus propiedades y los tokens que usa (y los nuevos que propone). Pedí cambios en tus palabras.
5. **Construir:** se crea en una página con su nombre, con component set, propiedades de texto y de mostrar/ocultar, y, para componentes hechos de partes (Stepper, Tabs), la composición armada con instancias. Después se verifica variante por variante.

Si tu sistema tiene una colección de tokens de componente (tres capas), además se crean los tokens del componente (por ejemplo `Tooltip/background` → tu semántico). Los íconos que falten se crean en la página «Íconos»; si ya tenés íconos llamados `Icon/…`, se reutilizan.

Lo que no es visual (cuándo aparece un tooltip, cuánto dura un toast, foco) queda escrito en la descripción del componente.

## Documentación (nuevo)

En la pantalla inicial, cuando el archivo ya tiene Variables, aparece **Crear o actualizar documentación →**. También está al final de construir las fundaciones o los componentes.

1. **Leer el archivo:** Variables con su cadena de alias (y sus valores en claro y oscuro), Text Styles, component sets con lo que tiene bindeado cada uno, y una imagen de cada componente. Solo lee.
2. **¿Ya generaste documentación antes?** Elegí el `ds-docs-v….zip` que descargaste la última vez. Así se mantienen los textos aprobados y la guía, y la versión siguiente se completa sola. La primera vez, salteá este paso.
3. **Generar documentación → Descargar.** El .zip es un sitio estático: se publica tal cual en Netlify Drop o GitHub Pages.

**Textos de cada componente.** Descripción, Anatomía, Accesibilidad y Ejemplos de uso vienen completos:
- **Calculado desde Figma** (exacto): Anatomía (capas en orden, cuáles son opcionales o editables) y la parte medible de Accesibilidad (contraste de cada texto e ícono en claro y oscuro, área táctil, foco). La descripción de los componentes creados conversando también sale de Figma. Se actualiza en cada export.
- **Borrador redactado por Claude** (opción del paso 4, usa tu API key): descripción con usar / no usar, implementación accesible (rol, teclado, lectores de pantalla) y ejemplos correcto e incorrecto. Claude parte de los datos medidos y no puede contradecirlos.
- Cada sección muestra su origen. Los borradores quedan marcados «Borrador · revisar» hasta que, en un export siguiente, marques el componente como **Revisado**. Los textos aprobados no se vuelven a redactar. Sin API key se completa lo medible y el resto queda pendiente.

El sitio trae páginas para personas (inicio, guía, tokens, auditoría contra las reglas, una página por componente) y una capa para agentes (`llms.txt`, `manifest.json`, tokens DTCG en tres archivos, `snapshot.json`, Markdown por componente). Los textos de cada componente viven en `textos/*.md` dentro del .zip: si un componente cambia en Figma desde la última revisión, su página dice «Revisar textos».

**Para abrirlo en tu computadora:** descomprimilo y abrí `index.html`. En macOS, si lo guardás dentro de Documentos, Chrome necesita permiso para esa carpeta (Ajustes del Sistema → Privacidad y seguridad → Archivos y carpetas → Google Chrome → Carpeta Documentos). Safari funciona sin ese paso. Publicado en un hosting no hace falta nada.

## Qué mirar

- ¿Las propuestas se sienten basadas en *tus* pantallas o genéricas?
- ¿El resumen de cada paso explica lo suficiente para decidir?
- ¿Pedir un cambio en tus palabras funciona? Probá algo que rompa una regla (por ejemplo, "usá el coral original para el botón") y fijate cómo responde.
- ¿Cuánto tarda cada propuesta? ¿Sonnet alcanza o hace falta Opus?
- En Figma: ¿las variables y estilos quedaron como esperabas? Cambiá un primitivo y mirá cómo se actualiza todo.

## Límites conocidos

- Componentes por conversación: no modela estados interactivos reales (hover en Figma se ve como variante), ni overlays posicionados; las flechas de un tooltip se dibujan con formas simples. Si cerrás el plugin a mitad de una conversación, hay que empezarla de nuevo.

- Documentación: los textos de cada componente (descripción, anatomía, accesibilidad, ejemplos) todavía no los redacta Claude; los componentes nuevos salen con secciones pendientes. Decisiones y changelog salen vacíos hasta que exista el registro de decisiones.

- La API key queda guardada en esta computadora (almacenamiento del plugin). Es solución de prototipo.
- Sombras no se tokenizan todavía.
- Componentes: el Select es la versión cerrada (sin menú desplegado) y los íconos son tres básicos (más, flecha, tilde) para reemplazar por tu set.
- La tipografía no tiene capa semántica: los Text Styles se atan directo a primitivos de tamaño e interlineado.
- Si la familia tipográfica no está instalada, usa la más cercana y lo avisa.
- El progreso se guarda por usuario: si cerrás el plugin a mitad de camino, retoma desde el último paso aprobado.
