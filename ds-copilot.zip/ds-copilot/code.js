// DS Diagnóstico — prototipo 1
// Lee el archivo abierto y detecta el design system implícito.
// No escribe nada en el archivo: solo lee y, si el usuario lo pide, selecciona nodos.

// ---------------------------------------------------------------------------
// Utilidades de color (OKLab para comparar colores como los percibe el ojo)
// ---------------------------------------------------------------------------
function toHex(c) {
  return '#' + [c.r, c.g, c.b].map(function (v) {
    return Math.round(v * 255).toString(16).padStart(2, '0');
  }).join('').toUpperCase();
}
function hexToRgb(hex) {
  var n = parseInt(hex.slice(1), 16);
  return { r: ((n >> 16) & 255) / 255, g: ((n >> 8) & 255) / 255, b: (n & 255) / 255 };
}
function lin(v) { return v <= 0.04045 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }
function toOklab(hex) {
  var c = hexToRgb(hex), r = lin(c.r), g = lin(c.g), b = lin(c.b);
  var l = Math.cbrt(0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b);
  var m = Math.cbrt(0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b);
  var s = Math.cbrt(0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b);
  var L = 0.2104542553 * l + 0.7936177850 * m - 0.0040720468 * s;
  var A = 1.9779984951 * l - 2.4285922050 * m + 0.4505937099 * s;
  var B = 0.0259040371 * l + 0.7827717662 * m - 0.8086757660 * s;
  var C = Math.sqrt(A * A + B * B);
  var H = (Math.atan2(B, A) * 180 / Math.PI + 360) % 360;
  return { L: L, a: A, b: B, C: C, H: H };
}
function dist(p, q) {
  return Math.sqrt(Math.pow(p.L - q.L, 2) + Math.pow(p.a - q.a, 2) + Math.pow(p.b - q.b, 2));
}
function luminance(hex) {
  var c = hexToRgb(hex);
  return 0.2126 * lin(c.r) + 0.7152 * lin(c.g) + 0.0722 * lin(c.b);
}
function contrast(h1, h2) {
  var a = luminance(h1), b = luminance(h2);
  return (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05);
}

// Familia de un color. Grises (fríos o cálidos) van a Neutros; los tintes claros con tono
// (fondos de tarjeta verdes, azules…) van con su familia de color, porque suelen ser
// decisiones de acento, no de superficie.
function familyOf(lab) {
  var h = lab.H;
  if (lab.C < 0.005) return 'Neutros';
  if (lab.C < 0.03 && lab.L < 0.9) return 'Neutros';
  if (lab.C < 0.03 && h >= 60 && h < 110) return 'Neutros';
  if (h < 50 || h >= 345) return 'Rojos y corales';
  if (h < 85) return 'Naranjas';
  if (h < 115) return 'Amarillos';
  if (h < 175) return 'Verdes';
  if (h < 225) return 'Turquesas';
  if (h < 275) return 'Azules';
  if (h < 320) return 'Violetas';
  return 'Rosas';
}
var FAMILY_ORDER = ['Neutros', 'Rojos y corales', 'Naranjas', 'Amarillos', 'Verdes', 'Turquesas', 'Azules', 'Violetas', 'Rosas'];

// ---------------------------------------------------------------------------
// Análisis (funciones puras sobre los datos crudos — testeables fuera de Figma)
// ---------------------------------------------------------------------------
// Distancia OKLab bajo la cual dos colores se perciben "casi iguales".
// Calibrado: separa blanco de crema (#FFF vs #FAF7F2 = 0.024) pero junta tintes gemelos (#FEF3F2 vs #FDF4F2 = 0.003).
var NEAR = 0.02;

function analyzeColors(colors) {
  var all = Object.keys(colors).map(function (k) { return colors[k]; });
  var solids = all.filter(function (c) { return c.alpha >= 0.99; });
  var translucent = all.filter(function (c) { return c.alpha < 0.99 && c.alpha > 0.001; });
  var invisible = all.filter(function (c) { return c.alpha <= 0.001; }).length;
  solids.forEach(function (c) { c.lab = toOklab(c.hex); c.uses = c.fill + c.text + c.stroke; });
  solids.sort(function (x, y) { return y.uses - x.uses; });

  // Agrupamiento greedy: el color más usado de cada grupo es el representante.
  var clusters = [];
  solids.forEach(function (c) {
    var target = null;
    for (var i = 0; i < clusters.length; i++) {
      if (familyOf(clusters[i].rep.lab) === familyOf(c.lab) && dist(clusters[i].rep.lab, c.lab) < NEAR) { target = clusters[i]; break; }
    }
    if (target) target.members.push(c);
    else clusters.push({ rep: c, members: [c] });
  });
  var out = clusters.map(function (cl) {
    var uses = 0, fill = 0, text = 0, stroke = 0, bound = 0, ids = [];
    cl.members.forEach(function (m) {
      uses += m.uses; fill += m.fill; text += m.text; stroke += m.stroke; bound += m.bound;
      ids = ids.concat(m.ids);
    });
    return {
      hex: cl.rep.hex, family: familyOf(cl.rep.lab), L: cl.rep.lab.L,
      members: cl.members.map(function (m) { return { hex: m.hex, uses: m.uses, ids: m.ids.slice(0, 200) }; }),
      uses: uses, fill: fill, text: text, stroke: stroke, bound: bound, ids: ids.slice(0, 200)
    };
  });
  var families = {};
  out.forEach(function (c) { (families[c.family] = families[c.family] || []).push(c); });
  var famList = FAMILY_ORDER.filter(function (f) { return families[f]; }).map(function (f) {
    return { name: f, clusters: families[f].sort(function (a, b) { return b.L - a.L; }) };
  });
  var totalUses = 0, boundUses = 0;
  out.forEach(function (c) { totalUses += c.uses; boundUses += c.bound; });
  return {
    uniqueSolid: solids.length,
    uniqueTranslucent: translucent.length,
    invisible: invisible,
    groups: out.length,
    merged: out.filter(function (c) { return c.members.length > 1; }),
    families: famList,
    translucent: translucent.map(function (c) { return { hex: c.hex, alpha: c.alpha }; }),
    boundPct: totalUses ? Math.round(100 * boundUses / totalUses) : 0
  };
}

function analyzeType(fonts) {
  var list = Object.keys(fonts).map(function (k) { return fonts[k]; });
  var families = {}, sizes = {}, ratios = {}, styles = {};
  var total = 0;
  list.forEach(function (f) {
    total += f.count;
    families[f.family] = (families[f.family] || 0) + f.count;
    styles[f.style] = (styles[f.style] || 0) + f.count;
    var s = sizes[f.size] = sizes[f.size] || { size: f.size, count: 0, styles: {} };
    s.count += f.count; s.styles[f.style] = true;
    if (f.lh != null) {
      var r = Math.round(100 * f.lh / f.size);
      ratios[r] = (ratios[r] || 0) + f.count;
    } else ratios['auto'] = (ratios['auto'] || 0) + f.count;
  });
  var sizeList = Object.keys(sizes).map(function (k) { return sizes[k]; }).sort(function (a, b) { return a.size - b.size; });
  sizeList.forEach(function (s) { s.styles = Object.keys(s.styles); });
  var decimalLh = list.filter(function (f) { return f.lh != null && Math.round(f.lh) !== f.lh; });
  return {
    total: total,
    combos: list.length,
    families: Object.keys(families).map(function (k) { return { name: k, count: families[k] }; }).sort(function (a, b) { return b.count - a.count; }),
    sizes: sizeList,
    rare: sizeList.filter(function (s) { return s.count <= 2; }).map(function (s) { return s.size; }),
    styles: Object.keys(styles).map(function (k) { return { name: k, count: styles[k] }; }).sort(function (a, b) { return b.count - a.count; }),
    ratios: Object.keys(ratios).map(function (k) { return { ratio: k, count: ratios[k] }; }).sort(function (a, b) { return b.count - a.count; }),
    decimalLh: decimalLh.map(function (f) { return f.size + '/' + f.lh; }).filter(function (v, i, a) { return a.indexOf(v) === i; })
  };
}

function analyzeSpacing(spacing) {
  var list = Object.keys(spacing).map(function (k) { return spacing[k]; });
  var structural = [], decimals = [], large = [];
  list = list.filter(function (s) { return s.value >= 0.5; });
  list.forEach(function (s) {
    if (s.value > 64) large.push(s);
    else if (Math.abs(s.value - Math.round(s.value)) > 0.01) decimals.push(s);
    else structural.push(s);
  });
  structural.sort(function (a, b) { return a.value - b.value; });
  var total = 0, on4 = 0, on2 = 0;
  structural.forEach(function (s) {
    total += s.count;
    if (s.value % 4 === 0) on4 += s.count;
    if (s.value % 2 === 0) on2 += s.count;
  });
  // Fuera de grilla, ordenados por uso: el más usado es el que más conviene decidir.
  var off4 = structural.filter(function (s) { return s.value % 4 !== 0; }).sort(function (a, b) { return b.count - a.count; });
  return {
    unique: list.length,
    structural: structural.map(function (s) { return { value: s.value, count: s.count, onGrid: s.value % 4 === 0, ids: s.ids.slice(0, 200) }; }),
    on4Pct: total ? Math.round(100 * on4 / total) : 0,
    on2Pct: total ? Math.round(100 * on2 / total) : 0,
    off4: off4.map(function (s) { return s.value + ' (×' + s.count + ')'; }),
    decimals: decimals.length,
    decimalIds: decimals.reduce(function (a, s) { return a.concat(s.ids); }, []).slice(0, 200),
    large: large.length
  };
}

function analyzeRadii(radii) {
  return Object.keys(radii).map(function (k) { return radii[k]; })
    .sort(function (a, b) { return a.value - b.value; })
    .map(function (r) { return { value: r.value, label: r.value >= 999 ? 'pill' : r.value + 'px', count: r.count, ids: r.ids.slice(0, 200) }; });
}

function analyzeEffects(effects) {
  return Object.keys(effects).map(function (k) { return effects[k]; })
    .sort(function (a, b) { return b.count - a.count; })
    .map(function (e) { return { desc: e.desc, count: e.count, ids: e.ids.slice(0, 200) }; });
}

// Estructuras repetidas = candidatos a componente. Se quedan solo los grupos "externos":
// si un grupo vive siempre dentro de otro grupo repetido, es una parte, no un componente.
function analyzeStructures(cands) {
  var bySig = {};
  cands.forEach(function (c) { (bySig[c.sig] = bySig[c.sig] || []).push(c); });
  var groups = Object.keys(bySig).map(function (k) { return bySig[k]; })
    .filter(function (g) { return g.length >= 2; })
    .sort(function (a, b) { return b[0].size - a[0].size; });
  var kept = [], keptIds = {};
  groups.forEach(function (g) {
    var inside = g.filter(function (c) { return c.ancestors.some(function (a) { return keptIds[a]; }); }).length;
    if (inside / g.length >= 0.5) return;
    kept.push(g);
    g.forEach(function (c) { keptIds[c.id] = true; });
  });
  return kept.map(function (g) {
    var labels = [];
    g.forEach(function (c) { if (c.label && labels.indexOf(c.label) < 0) labels.push(c.label); });
    return { count: g.length, size: Math.round(g[0].w) + '×' + Math.round(g[0].h), depth: g[0].size, labels: labels.slice(0, 4), ids: g.map(function (c) { return c.id; }) };
  }).sort(function (a, b) { return b.count * b.depth - a.count * a.depth; }).slice(0, 12);
}

function analyze(raw) {
  var colors = analyzeColors(raw.colors);
  var type = analyzeType(raw.fonts);
  var spacing = analyzeSpacing(raw.spacing);
  var radii = analyzeRadii(raw.radii);
  var effects = analyzeEffects(raw.effects);
  var structures = analyzeStructures(raw.cands);

  // Contraste: pares texto/fondo más comunes que no llegan a AA.
  var lowContrast = [];
  Object.keys(raw.textOnBg).forEach(function (k) {
    var p = raw.textOnBg[k], ratio = contrast(p.fg, p.bg);
    var need = p.large ? 3 : 4.5;
    if (ratio < need) lowContrast.push({ fg: p.fg, bg: p.bg, ratio: Math.round(ratio * 100) / 100, need: need, count: p.count, ids: p.ids.slice(0, 200) });
  });
  lowContrast.sort(function (a, b) { return b.count - a.count; });

  return {
    totals: raw.totals,
    existing: raw.existing,
    colors: colors, type: type, spacing: spacing, radii: radii, effects: effects,
    structures: structures, lowContrast: lowContrast.slice(0, 8)
  };
}

// ---------------------------------------------------------------------------
// Recolección (lee nodos visibles del archivo)
// ---------------------------------------------------------------------------
function hash(str) {
  var h = 5381;
  for (var i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) | 0;
  return (h >>> 0).toString(36);
}
function bump(map, key, init, id) {
  var e = map[key];
  if (!e) { e = map[key] = init; e.count = 0; e.ids = []; }
  e.count++;
  if (id && e.ids.length < 300) e.ids.push(id);
  return e;
}

function createRaw() {
  return { colors: {}, fonts: {}, spacing: {}, radii: {}, effects: {}, cands: [], textOnBg: {}, totals: { nodes: 0, pages: 0, frames: 0, autoLayout: 0 } };
}

function addColor(raw, paint, nodeOpacity, kind, id) {
  if (paint.visible === false) return null;
  if (paint.type !== 'SOLID') return null;
  var alpha = Math.round((paint.opacity == null ? 1 : paint.opacity) * nodeOpacity * 100) / 100;
  var hex = toHex(paint.color);
  var key = alpha >= 0.99 ? hex : hex + '@' + Math.round(alpha * 100);
  var e = raw.colors[key];
  if (!e) e = raw.colors[key] = { hex: hex, alpha: alpha, fill: 0, text: 0, stroke: 0, bound: 0, ids: [] };
  e[kind]++;
  if (paint.boundVariables && paint.boundVariables.color) e.bound++;
  if (e.ids.length < 300) e.ids.push(id);
  return alpha >= 0.99 ? hex : null;
}

// Fondo efectivo para medir contraste. El fill visible de más arriba manda:
// si es sólido y opaco, es el fondo; si es gradiente, imagen o transparente, el fondo
// es desconocido y no se mide (evita falsos positivos). Sin fills, se hereda.
var UNKNOWN_BG = 'unknown';
function effectiveBg(node, inherited) {
  if (!('fills' in node) || !Array.isArray(node.fills)) return inherited;
  for (var i = node.fills.length - 1; i >= 0; i--) {
    var f = node.fills[i];
    if (f.visible === false) continue;
    if (f.type === 'SOLID' && (f.opacity == null || f.opacity >= 0.99) && node.opacity >= 0.99) return toHex(f.color);
    return UNKNOWN_BG;
  }
  return inherited;
}

function walk(node, raw, ctx, ancestors, bg, insideInstance) {
  if ('visible' in node && node.visible === false) return null;
  raw.totals.nodes++;
  var id = node.id, op = 'opacity' in node ? node.opacity : 1;
  var myBg = bg;

  if (node.type === 'TEXT') {
    var segs = node.getStyledTextSegments(['fontName', 'fontSize', 'lineHeight', 'fills']);
    segs.forEach(function (s) {
      var lh = s.lineHeight.unit === 'PIXELS' ? Math.round(s.lineHeight.value * 10) / 10
        : s.lineHeight.unit === 'PERCENT' ? Math.round(s.lineHeight.value * s.fontSize) / 100 : null;
      var key = s.fontName.family + '|' + s.fontName.style + '|' + s.fontSize + '|' + lh;
      bump(raw.fonts, key, { family: s.fontName.family, style: s.fontName.style, size: s.fontSize, lh: lh }, id);
      s.fills.forEach(function (f) {
        var fg = addColor(raw, f, op, 'text', id);
        if (fg && bg && bg !== UNKNOWN_BG) {
          var bold = /bold|black|heavy|semi/i.test(s.fontName.style);
          var large = s.fontSize >= 18 || (s.fontSize >= 14 && bold);
          var k = fg + '|' + bg + '|' + (large ? 'L' : 'N');
          var e = raw.textOnBg[k];
          if (!e) e = raw.textOnBg[k] = { fg: fg, bg: bg, large: large, count: 0, ids: [] };
          e.count++; if (e.ids.length < 300) e.ids.push(id);
        }
      });
    });
  } else if ('fills' in node && Array.isArray(node.fills)) {
    node.fills.forEach(function (f) { addColor(raw, f, op, 'fill', id); });
    myBg = effectiveBg(node, bg);
  }
  if ('strokes' in node && Array.isArray(node.strokes) && node.strokes.length && node.strokeWeight !== 0) {
    node.strokes.forEach(function (f) { addColor(raw, f, op, 'stroke', id); });
  }
  if ('cornerRadius' in node && node.type !== 'TEXT') {
    var r = node.cornerRadius;
    if (typeof r === 'number' && r > 0) bump(raw.radii, String(r), { value: r }, id);
  }
  if ('effects' in node && Array.isArray(node.effects)) {
    node.effects.forEach(function (e) {
      if (e.visible === false) return;
      var desc = e.type === 'DROP_SHADOW' || e.type === 'INNER_SHADOW'
        ? (e.type === 'DROP_SHADOW' ? 'Sombra' : 'Sombra interna') + ' y' + Math.round(e.offset.y) + ' blur ' + Math.round(e.radius) + ' ' + toHex(e.color) + ' ' + Math.round(e.color.a * 100) + '%'
        : (e.type === 'BACKGROUND_BLUR' ? 'Blur de fondo ' : 'Blur ') + Math.round(e.radius);
      bump(raw.effects, desc, { desc: desc }, id);
    });
  }
  if ((node.type === 'FRAME' || node.type === 'COMPONENT' || node.type === 'INSTANCE') && 'layoutMode' in node) {
    raw.totals.frames++;
    if (node.layoutMode !== 'NONE') {
      raw.totals.autoLayout++;
      [node.paddingTop, node.paddingRight, node.paddingBottom, node.paddingLeft].forEach(function (p) {
        if (p > 0) bump(raw.spacing, String(p), { value: p }, id);
      });
      if (node.itemSpacing > 0 && node.primaryAxisAlignItems !== 'SPACE_BETWEEN') bump(raw.spacing, String(node.itemSpacing), { value: node.itemSpacing }, id);
    }
  }

  var childSigs = [], size = 1, label = node.type === 'TEXT' ? node.characters.slice(0, 40) : null;
  if ('children' in node) {
    var nextAnc = node.type === 'FRAME' ? ancestors.concat([id]) : ancestors;
    var inInst = insideInstance || node.type === 'INSTANCE';
    for (var i = 0; i < node.children.length; i++) {
      var res = walk(node.children[i], raw, ctx, nextAnc, myBg, inInst);
      if (!res) continue;
      childSigs.push(res.sig); size += res.size;
      if (!label && res.label) label = res.label;
    }
  }
  var lm = 'layoutMode' in node && node.layoutMode && node.layoutMode !== 'NONE' ? node.layoutMode[0] : '';
  var sig = hash(node.type + lm + '(' + childSigs.join(',') + ')');
  if (node.type === 'FRAME' && !insideInstance && size >= 5 && node.parent && node.parent.type !== 'PAGE' && node.parent.type !== 'SECTION') {
    raw.cands.push({ id: id, sig: sig, size: size, w: node.width, h: node.height, label: label, ancestors: ancestors });
  }
  return { sig: sig, size: size, label: label };
}

async function collectExisting() {
  var cols = await figma.variables.getLocalVariableCollectionsAsync();
  var vars = 0; cols.forEach(function (c) { vars += c.variableIds.length; });
  return {
    variables: vars, collections: cols.length,
    textStyles: (await figma.getLocalTextStylesAsync()).length,
    paintStyles: (await figma.getLocalPaintStylesAsync()).length,
    effectStyles: (await figma.getLocalEffectStylesAsync()).length,
    components: 0, instances: 0
  };
}

async function run(scope) {
  var raw = createRaw();
  var pages = [figma.currentPage];
  if (scope === 'file') {
    figma.ui.postMessage({ type: 'progress', text: 'Cargando páginas…' });
    await figma.loadAllPagesAsync();
    pages = figma.root.children.slice();
  }
  raw.existing = await collectExisting();
  for (var p = 0; p < pages.length; p++) {
    var page = pages[p];
    raw.totals.pages++;
    figma.ui.postMessage({ type: 'progress', text: 'Leyendo «' + page.name + '» (' + (p + 1) + ' de ' + pages.length + ')…' });
    await new Promise(function (r) { setTimeout(r, 0); });
    raw.existing.components += page.findAllWithCriteria({ types: ['COMPONENT', 'COMPONENT_SET'] }).length;
    raw.existing.instances += page.findAllWithCriteria({ types: ['INSTANCE'] }).length;
    var roots = scope === 'selection' ? figma.currentPage.selection.slice() : page.children;
    if (scope === 'selection') raw.totals.selection = roots.length;
    for (var i = 0; i < roots.length; i++) {
      walk(roots[i], raw, {}, [], null, false);
      if (i % 5 === 4) {
        figma.ui.postMessage({ type: 'progress', text: 'Leyendo «' + page.name + '»: ' + raw.totals.nodes + ' capas…' });
        await new Promise(function (r) { setTimeout(r, 0); });
      }
    }
  }
  figma.ui.postMessage({ type: 'progress', text: 'Agrupando ' + raw.totals.nodes + ' capas…' });
  await new Promise(function (r) { setTimeout(r, 0); });
  return analyze(raw);
}

// ---------------------------------------------------------------------------
// Reglas duras (no negociables). Viven en código, no en el modelo:
// la IA propone, estas reglas validan antes de mostrar y después de construir.
// ---------------------------------------------------------------------------
var COLLECTIONS = { primitives: 'Primitives', semantic: 'Semantic' }; // contrato: nombres fijos (regla 6.5)
var MODES = ['Light', 'Dark'];
var REQUIRED_SEMANTICS = [
  'color/background/primary', 'color/background/secondary',
  'color/text/primary', 'color/text/secondary', 'color/text/disabled', 'color/text/inverse',
  'color/border/default',
  'color/action/primary/default', 'color/action/primary/hover', 'color/action/focus',
  'color/status/success/background', 'color/status/success/content',
  'color/status/warning/background', 'color/status/warning/content',
  'color/status/danger/background', 'color/status/danger/content',
  'color/status/info/background', 'color/status/info/content'
];

// Pares de contraste a verificar, derivados de los nombres semánticos.
function contrastPairs(semNames) {
  var has = function (n) { return semNames.indexOf(n) >= 0; };
  var pairs = [];
  var bgs = ['color/background/primary', 'color/background/secondary'].filter(has);
  semNames.forEach(function (n) {
    if (/^color\/text\//.test(n) && !/disabled|inverse/.test(n)) {
      bgs.forEach(function (bg) { pairs.push({ fg: n, bg: bg, need: 4.5, level: 'error' }); });
    }
    var st = n.match(/^color\/status\/([^/]+)\/content$/);
    if (st && has('color/status/' + st[1] + '/background')) pairs.push({ fg: n, bg: 'color/status/' + st[1] + '/background', need: 4.5, level: 'error' });
  });
  if (has('color/text/inverse') && has('color/action/primary/default')) pairs.push({ fg: 'color/text/inverse', bg: 'color/action/primary/default', need: 4.5, level: 'error' });
  if (has('color/action/focus') && bgs[0]) pairs.push({ fg: 'color/action/focus', bg: bgs[0], need: 3, level: 'error' });
  if (has('color/action/primary/default') && bgs[0]) pairs.push({ fg: 'color/action/primary/default', bg: bgs[0], need: 3, level: 'warn' });
  if (has('color/border/default') && bgs[0]) pairs.push({ fg: 'color/border/default', bg: bgs[0], need: 3, level: 'warn' });
  return pairs;
}

var NAME_RULES = {
  colorPrimitive: /^Color\/[A-Z][A-Za-z]*\/(0|00|50|[1-9]00|950)$/,
  semantic: /^color\/[a-z]+(\/[a-z0-9-]+)+$/,
  size: /^Typography\/size\/[a-z0-9-]+$/,
  lineHeight: /^Typography\/line-height\/[a-z0-9-]+$/,
  space: /^Space\/[A-Za-z0-9-]+$/,
  radius: /^Radius\/[A-Za-z0-9-]+$/,
  textStyle: /^[A-Z][A-Za-z]*\/[A-Z0-9]+$/
};

// Valida una propuesta de un paso. Devuelve { errors, warnings, passed } en lenguaje claro.
function validateStep(step, p) {
  var errors = [], warnings = [], passed = [];
  function need(cond, msg) { if (!cond) errors.push(msg); return cond; }
  function desc(list, label) {
    var missing = list.filter(function (x) { return !x.description || x.description.trim().length < 8; }).map(function (x) { return x.name; });
    if (missing.length) errors.push(label + ' sin descripción: ' + missing.slice(0, 6).join(', '));
  }
  function dupes(list, label) {
    var seen = {}, d = [];
    list.forEach(function (x) { if (seen[x.name]) d.push(x.name); seen[x.name] = true; });
    if (d.length) errors.push(label + ' repetidos: ' + d.join(', '));
  }
  if (step === 'color') {
    var prims = p.primitives || [], sems = p.semantics || [];
    var byName = {}; prims.forEach(function (x) { byName[x.name] = x; });
    dupes(prims, 'Primitivos'); dupes(sems, 'Semánticos');
    var badP = prims.filter(function (x) { return !NAME_RULES.colorPrimitive.test(x.name); }).map(function (x) { return x.name; });
    if (badP.length) errors.push('Primitivos con nombre fuera de la convención Color/{Familia}/{50…950}: ' + badP.join(', '));
    var badHex = prims.filter(function (x) { return !/^#[0-9A-F]{6}$/i.test(x.hex || ''); }).map(function (x) { return x.name; });
    if (badHex.length) errors.push('Primitivos con hex inválido: ' + badHex.join(', '));
    var badS = sems.filter(function (x) { return !NAME_RULES.semantic.test(x.name); }).map(function (x) { return x.name; });
    if (badS.length) errors.push('Semánticos con nombre fuera de la convención color/{rol}/{variante}: ' + badS.join(', '));
    var semNames = sems.map(function (x) { return x.name; });
    var missing = REQUIRED_SEMANTICS.filter(function (n) { return semNames.indexOf(n) < 0; });
    if (missing.length) errors.push('Faltan semánticos obligatorios: ' + missing.join(', '));
    var broken = [];
    sems.forEach(function (s) { MODES.forEach(function (m) { var ref = s[m.toLowerCase()]; if (!byName[ref]) broken.push(s.name + ' (' + m + ' → ' + ref + ')'); }); });
    if (broken.length) errors.push('Semánticos que apuntan a un primitivo inexistente (nada se hardcodea): ' + broken.slice(0, 8).join(', '));
    desc(prims, 'Primitivos'); desc(sems, 'Semánticos');
    var unused = prims.filter(function (x) { return !sems.some(function (s) { return s.light === x.name || s.dark === x.name; }); }).map(function (x) { return x.name; });
    if (unused.length) warnings.push('Primitivos que ningún semántico usa todavía: ' + unused.join(', '));
    if (!broken.length) {
      var hexOf = function (sem, mode) { var s = sems.filter(function (x) { return x.name === sem; })[0]; return byName[s[mode]].hex; };
      var pairs = contrastPairs(semNames), ok = 0;
      pairs.forEach(function (pr) {
        ['light', 'dark'].forEach(function (mode) {
          var r = Math.round(contrast(hexOf(pr.fg, mode), hexOf(pr.bg, mode)) * 100) / 100;
          var tag = pr.fg.replace('color/', '') + ' sobre ' + pr.bg.replace('color/', '') + ' (' + (mode === 'light' ? 'claro' : 'oscuro') + '): ' + r + ':1, necesita ' + pr.need + ':1';
          if (r < pr.need) (pr.level === 'error' ? errors : warnings).push('Contraste insuficiente: ' + tag);
          else ok++;
        });
      });
      passed.push(ok + ' de ' + pairs.length * 2 + ' pares de contraste pasan en claro y oscuro');
    }
    passed.push(prims.length + ' primitivos y ' + sems.length + ' semánticos con nombre y descripción válidos');
  } else if (step === 'type') {
    var sizes = p.sizes || [], lhs = p.lineHeights || [], styles = p.styles || [];
    need(p.family && p.family.length > 1, 'Falta la familia tipográfica');
    dupes(sizes, 'Tamaños'); dupes(lhs, 'Interlineados'); dupes(styles, 'Estilos');
    var bad = sizes.filter(function (x) { return !NAME_RULES.size.test(x.name); }).concat(lhs.filter(function (x) { return !NAME_RULES.lineHeight.test(x.name); }))
      .concat(styles.filter(function (x) { return !NAME_RULES.textStyle.test(x.name); })).map(function (x) { return x.name; });
    if (bad.length) errors.push('Nombres fuera de convención: ' + bad.join(', '));
    var sz = {}, lh = {}; sizes.forEach(function (x) { sz[x.name] = x.value; }); lhs.forEach(function (x) { lh[x.name] = x.value; });
    var refs = styles.filter(function (s) { return sz[s.size] == null || lh[s.lineHeight] == null; }).map(function (s) { return s.name; });
    if (refs.length) errors.push('Estilos que apuntan a tamaños o interlineados inexistentes: ' + refs.join(', '));
    var dec = lhs.filter(function (x) { return Math.round(x.value) !== x.value; }).map(function (x) { return x.name + ' = ' + x.value; });
    if (dec.length) errors.push('Interlineados con decimales (usar px enteros): ' + dec.join(', '));
    styles.forEach(function (s) {
      if (sz[s.size] != null && lh[s.lineHeight] != null && lh[s.lineHeight] < sz[s.size]) errors.push(s.name + ': interlineado menor que el tamaño');
      if (sz[s.size] != null && sz[s.size] < 12) warnings.push(s.name + ': ' + sz[s.size] + 'px es chico para texto de lectura en web');
    });
    desc(sizes, 'Tamaños'); desc(lhs, 'Interlineados'); desc(styles, 'Estilos');
    passed.push(styles.length + ' estilos sobre ' + sizes.length + ' tamaños y ' + lhs.length + ' interlineados');
  } else if (step === 'space') {
    var sp = p.spacing || [], rd = p.radius || [];
    dupes(sp, 'Espaciados'); dupes(rd, 'Radios');
    var badN = sp.filter(function (x) { return !NAME_RULES.space.test(x.name); }).concat(rd.filter(function (x) { return !NAME_RULES.radius.test(x.name); })).map(function (x) { return x.name; });
    if (badN.length) errors.push('Nombres fuera de convención: ' + badN.join(', '));
    var off = sp.filter(function (x) { return x.value % 4 !== 0 && x.value !== 2; }).map(function (x) { return x.name + ' = ' + x.value; });
    if (off.length) errors.push('Espaciados fuera de la grilla de 4: ' + off.join(', '));
    var vals = sp.map(function (x) { return x.value; });
    if (vals.some(function (v, i) { return i && v <= vals[i - 1]; })) errors.push('La escala de espaciado tiene que ir de menor a mayor');
    desc(sp, 'Espaciados'); desc(rd, 'Radios');
    passed.push(sp.length + ' espaciados en grilla de 4 y ' + rd.length + ' radios');
  }
  return { errors: errors, warnings: warnings, passed: passed };
}

// ---------------------------------------------------------------------------
// Construcción en Figma
// ---------------------------------------------------------------------------
function hexToPaint(hex) { return hexToRgb(hex); }
function scopesFor(semName) {
  if (/^color\/text\//.test(semName)) return ['TEXT_FILL'];
  if (/^color\/border\//.test(semName) || semName === 'color/action/focus') return ['STROKE_COLOR'];
  if (/^color\/icon\//.test(semName)) return ['SHAPE_FILL', 'STROKE_COLOR'];
  if (/\/content$/.test(semName)) return ['TEXT_FILL', 'SHAPE_FILL', 'STROKE_COLOR'];
  return ['FRAME_FILL', 'SHAPE_FILL'];
}

async function loadFirstFont(cands) {
  for (var i = 0; i < cands.length; i++) {
    try { await figma.loadFontAsync(cands[i]); return cands[i]; } catch (e) { /* probar el siguiente */ }
  }
  return null;
}

async function build(plan, log) {
  var warnings = [];
  var existing = await figma.variables.getLocalVariableCollectionsAsync();
  var clash = existing.filter(function (c) { return c.name === COLLECTIONS.primitives || c.name === COLLECTIONS.semantic; });
  if (clash.length) throw new Error('Este archivo ya tiene colecciones llamadas «' + clash.map(function (c) { return c.name; }).join('» y «') + '». Usá un archivo nuevo para el design system.');

  log('Creando colecciones…');
  var prim = figma.variables.createVariableCollection(COLLECTIONS.primitives);
  prim.renameMode(prim.modes[0].modeId, 'Value');
  var pm = prim.modes[0].modeId;
  var sem = figma.variables.createVariableCollection(COLLECTIONS.semantic);
  sem.renameMode(sem.modes[0].modeId, 'Light');
  var lightId = sem.modes[0].modeId;
  var darkId = sem.addMode('Dark');

  var byName = {};
  function mk(name, coll, type, value, scopes, description) {
    var v = figma.variables.createVariable(name, coll, type);
    v.setValueForMode(coll === prim ? pm : lightId, value);
    v.scopes = scopes;
    v.description = description || '';
    byName[name] = v;
    return v;
  }

  log('Creando ' + plan.color.primitives.length + ' primitivos de color…');
  plan.color.primitives.forEach(function (c) {
    mk(c.name, prim, 'COLOR', hexToPaint(c.hex), [], c.description); // primitivos ocultos de los pickers
  });
  log('Creando tipografía y espaciado…');
  plan.type.sizes.forEach(function (s) { mk(s.name, prim, 'FLOAT', s.value, ['FONT_SIZE'], s.description); });
  plan.type.lineHeights.forEach(function (s) { mk(s.name, prim, 'FLOAT', s.value, ['LINE_HEIGHT'], s.description); });
  plan.space.spacing.forEach(function (s) { mk(s.name, prim, 'FLOAT', s.value, ['GAP'], s.description); });
  plan.space.radius.forEach(function (s) { mk(s.name, prim, 'FLOAT', s.value, ['CORNER_RADIUS'], s.description); });

  log('Creando ' + plan.color.semantics.length + ' semánticos con modo claro y oscuro…');
  plan.color.semantics.forEach(function (s) {
    var v = figma.variables.createVariable(s.name, sem, 'COLOR');
    v.setValueForMode(lightId, figma.variables.createVariableAlias(byName[s.light]));
    v.setValueForMode(darkId, figma.variables.createVariableAlias(byName[s.dark]));
    v.scopes = scopesFor(s.name);
    v.description = s.description || '';
    byName[s.name] = v;
  });

  log('Creando Text Styles…');
  var styles = {};
  var available = await figma.listAvailableFontsAsync();
  for (var i = 0; i < plan.type.styles.length; i++) {
    var st = plan.type.styles[i];
    var font = { family: plan.type.family, style: st.style };
    var ok = available.some(function (f) { return f.fontName.family === font.family && f.fontName.style === font.style; });
    if (!ok) {
      var alt = available.filter(function (f) { return f.fontName.family === font.family; })[0];
      warnings.push('No encontré «' + font.family + ' ' + font.style + '» instalada' + (alt ? '; usé ' + alt.fontName.style : '; usé Inter'));
      font = alt ? alt.fontName : { family: 'Inter', style: 'Regular' };
    }
    await figma.loadFontAsync(font);
    var ts = figma.createTextStyle();
    ts.name = st.name;
    ts.description = st.description || '';
    ts.fontName = font;
    ts.fontSize = byName[st.size] ? byName[st.size].valuesByMode[pm] : 14;
    ts.lineHeight = { unit: 'PIXELS', value: byName[st.lineHeight] ? byName[st.lineHeight].valuesByMode[pm] : 20 };
    try {
      ts.setBoundVariable('fontSize', byName[st.size]);
      ts.setBoundVariable('lineHeight', byName[st.lineHeight]);
    } catch (e) {
      warnings.push(st.name + ': no pude atar tamaño/interlineado a variables (' + e.message + ')');
    }
    styles[st.name] = ts;
  }

  log('Dibujando la página Fundaciones…');
  var page = await drawFoundations(plan, byName, styles, sem, darkId);
  return { warnings: warnings, pageId: page.id };
}

function boundFill(v) { return figma.variables.setBoundVariableForPaint({ type: 'SOLID', color: { r: 0, g: 0, b: 0 } }, 'color', v); }

function autoFrame(name, dir, gap, pad) {
  var f = figma.createFrame();
  f.name = name;
  f.layoutMode = dir;
  f.primaryAxisSizingMode = 'AUTO';
  f.counterAxisSizingMode = 'AUTO';
  f.itemSpacing = gap || 0;
  f.paddingTop = f.paddingBottom = f.paddingLeft = f.paddingRight = pad || 0;
  f.fills = [];
  return f;
}

async function drawFoundations(plan, byName, styles, sem, darkId) {
  var label = await loadFirstFont([{ family: 'Inter', style: 'Regular' }, { family: 'Roboto', style: 'Regular' }]);
  var labelBold = await loadFirstFont([{ family: 'Inter', style: 'Semi Bold' }, { family: 'Inter', style: 'Bold' }, label]);
  var page = figma.createPage();
  page.name = 'Fundaciones';
  function txt(chars, size, bold, colorVar) {
    var t = figma.createText();
    t.fontName = bold ? labelBold : label;
    t.fontSize = size; t.characters = chars;
    if (colorVar) t.fills = [boundFill(colorVar)];
    return t;
  }
  var tp = byName['color/text/primary'], ts2 = byName['color/text/secondary'];

  function colorBoard(modeLabel) {
    var board = autoFrame('Colores · ' + modeLabel, 'VERTICAL', 20, 32);
    board.fills = [boundFill(byName['color/background/primary'])];
    board.cornerRadius = 16;
    board.appendChild(txt('Colores · ' + modeLabel, 20, true, tp));
    var groups = {};
    plan.color.semantics.forEach(function (s) { var g = s.name.split('/')[1]; (groups[g] = groups[g] || []).push(s); });
    Object.keys(groups).forEach(function (g) {
      var col = autoFrame(g, 'VERTICAL', 8, 0);
      col.appendChild(txt(g.toUpperCase(), 11, true, ts2));
      groups[g].forEach(function (s) {
        var row = autoFrame(s.name, 'HORIZONTAL', 10, 0);
        row.counterAxisAlignItems = 'CENTER';
        var sw = figma.createRectangle();
        sw.resize(32, 32); sw.cornerRadius = 6;
        sw.fills = [boundFill(byName[s.name])];
        if (byName['color/border/default']) { sw.strokes = [boundFill(byName['color/border/default'])]; sw.strokeWeight = 1; }
        row.appendChild(sw);
        row.appendChild(txt(s.name.replace('color/', ''), 12, false, tp));
        col.appendChild(row);
      });
      board.appendChild(col);
    });
    return board;
  }

  var root = autoFrame('Fundaciones', 'VERTICAL', 48, 0);
  var colors = autoFrame('Colores', 'HORIZONTAL', 32, 0);
  colors.counterAxisAlignItems = 'MIN';
  var light = colorBoard('Claro');
  var dark = colorBoard('Oscuro');
  dark.setExplicitVariableModeForCollection(sem, darkId);
  colors.appendChild(light); colors.appendChild(dark);
  root.appendChild(colors);

  var type = autoFrame('Tipografía', 'VERTICAL', 16, 32);
  type.fills = [boundFill(byName['color/background/primary'])]; type.cornerRadius = 16;
  type.appendChild(txt('Tipografía · ' + plan.type.family, 20, true, tp));
  for (var i = 0; i < plan.type.styles.length; i++) {
    var st = plan.type.styles[i];
    var row = autoFrame(st.name, 'HORIZONTAL', 24, 0);
    row.counterAxisAlignItems = 'CENTER';
    var name = txt(st.name, 12, false, ts2);
    name.resize(96, name.height);
    row.appendChild(name);
    var sample = figma.createText();
    await figma.loadFontAsync(styles[st.name].fontName);
    sample.characters = 'Ordenemos lo que ya diseñaste';
    await sample.setTextStyleIdAsync(styles[st.name].id);
    sample.fills = [boundFill(tp)];
    row.appendChild(sample);
    type.appendChild(row);
  }
  root.appendChild(type);

  var space = autoFrame('Espaciado y radios', 'VERTICAL', 12, 32);
  space.fills = [boundFill(byName['color/background/primary'])]; space.cornerRadius = 16;
  space.appendChild(txt('Espaciado y radios', 20, true, tp));
  var brand = byName['color/action/primary/default'];
  plan.space.spacing.forEach(function (s) {
    var row = autoFrame(s.name, 'HORIZONTAL', 16, 0);
    row.counterAxisAlignItems = 'CENTER';
    var n = txt(s.name + ' · ' + s.value, 12, false, ts2); n.resize(110, n.height);
    var bar = figma.createRectangle(); bar.resize(s.value, 16); bar.fills = [boundFill(brand)];
    bar.setBoundVariable('width', byName[s.name]);
    row.appendChild(n); row.appendChild(bar);
    space.appendChild(row);
  });
  var radii = autoFrame('Radios', 'HORIZONTAL', 16, 0);
  plan.space.radius.forEach(function (r) {
    var cell = autoFrame(r.name, 'VERTICAL', 6, 0);
    var box = figma.createRectangle(); box.resize(56, 56);
    box.fills = [boundFill(byName['color/background/secondary'])];
    box.strokes = [boundFill(brand)]; box.strokeWeight = 1.5;
    ['topLeftRadius', 'topRightRadius', 'bottomLeftRadius', 'bottomRightRadius'].forEach(function (k) { box.setBoundVariable(k, byName[r.name]); });
    cell.appendChild(box); cell.appendChild(txt(r.name.replace('Radius/', '') + ' · ' + (r.value >= 999 ? 'pill' : r.value), 11, false, ts2));
    radii.appendChild(cell);
  });
  space.appendChild(radii);
  root.appendChild(space);
  page.appendChild(root);
  root.x = 0; root.y = 0;
  return page;
}

// ---------------------------------------------------------------------------
// Verificación: lee lo que quedó en Figma y lo compara con lo aprobado
// ---------------------------------------------------------------------------
async function verify(plan) {
  var checks = [];
  function check(label, problems) { checks.push({ label: label, ok: problems.length === 0, problems: problems.slice(0, 8) }); }
  var colls = await figma.variables.getLocalVariableCollectionsAsync();
  var prim = colls.filter(function (c) { return c.name === COLLECTIONS.primitives; })[0];
  var sem = colls.filter(function (c) { return c.name === COLLECTIONS.semantic; })[0];
  check('Colecciones «' + COLLECTIONS.primitives + '» y «' + COLLECTIONS.semantic + '» con los nombres exactos del contrato', [prim ? '' : 'Falta ' + COLLECTIONS.primitives, sem ? '' : 'Falta ' + COLLECTIONS.semantic].filter(Boolean));
  if (!prim || !sem) return checks;
  var modeNames = sem.modes.map(function (m) { return m.name; });
  check('Semantic tiene modos Light y Dark', MODES.filter(function (m) { return modeNames.indexOf(m) < 0; }).map(function (m) { return 'Falta el modo ' + m; }));

  var all = await figma.variables.getLocalVariablesAsync();
  var byName = {}, byId = {};
  all.forEach(function (v) { byId[v.id] = v; var c = v.variableCollectionId === prim.id ? 'p' : v.variableCollectionId === sem.id ? 's' : null; if (c) byName[v.name] = v; });
  var pm = prim.modes[0].modeId;
  var mode = {}; sem.modes.forEach(function (m) { mode[m.name] = m.modeId; });

  var p1 = [];
  plan.color.primitives.forEach(function (c) {
    var v = byName[c.name];
    if (!v) return p1.push('Falta ' + c.name);
    var val = v.valuesByMode[pm];
    if (!val || toHex(val) !== c.hex.toUpperCase()) p1.push(c.name + ' vale ' + (val ? toHex(val) : '—') + ', se aprobó ' + c.hex);
    if (!v.description) p1.push(c.name + ' sin descripción');
  });
  var nums = plan.type.sizes.concat(plan.type.lineHeights, plan.space.spacing, plan.space.radius);
  nums.forEach(function (n) {
    var v = byName[n.name];
    if (!v) return p1.push('Falta ' + n.name);
    if (v.valuesByMode[pm] !== n.value) p1.push(n.name + ' vale ' + v.valuesByMode[pm] + ', se aprobó ' + n.value);
  });
  check((plan.color.primitives.length + nums.length) + ' primitivos con el valor aprobado', p1);

  var p2 = [], resolved = { Light: {}, Dark: {} };
  plan.color.semantics.forEach(function (s) {
    var v = byName[s.name];
    if (!v) return p2.push('Falta ' + s.name);
    MODES.forEach(function (m) {
      var val = v.valuesByMode[mode[m]];
      var expected = s[m.toLowerCase()];
      if (!val || val.type !== 'VARIABLE_ALIAS') return p2.push(s.name + ' (' + m + ') tiene un valor fijo en vez de un alias');
      var target = byId[val.id];
      if (!target || target.name !== expected) p2.push(s.name + ' (' + m + ') apunta a ' + (target ? target.name : 'nada') + ', se aprobó ' + expected);
      else resolved[m][s.name] = toHex(target.valuesByMode[pm]);
    });
    if (!v.description) p2.push(s.name + ' sin descripción');
    if (!v.scopes.length || v.scopes.indexOf('ALL_SCOPES') >= 0) p2.push(s.name + ' sin scopes específicos');
  });
  check(plan.color.semantics.length + ' semánticos apuntan a primitivos en claro y oscuro (nada hardcodeado)', p2);

  var p3 = [], pairs = contrastPairs(plan.color.semantics.map(function (s) { return s.name; }));
  pairs.filter(function (pr) { return pr.level === 'error'; }).forEach(function (pr) {
    MODES.forEach(function (m) {
      var a = resolved[m][pr.fg], b = resolved[m][pr.bg];
      if (!a || !b) return;
      var r = contrast(a, b);
      if (r < pr.need) p3.push(pr.fg.replace('color/', '') + ' sobre ' + pr.bg.replace('color/', '') + ' en ' + m + ': ' + (Math.round(r * 100) / 100) + ':1');
    });
  });
  check('Contraste AA medido sobre los valores reales en Figma, en los dos modos', p3);

  var tstyles = await figma.getLocalTextStylesAsync();
  var tsBy = {}; tstyles.forEach(function (t) { tsBy[t.name] = t; });
  var p4 = [];
  plan.type.styles.forEach(function (s) {
    var t = tsBy[s.name];
    if (!t) return p4.push('Falta el Text Style ' + s.name);
    var bv = t.boundVariables || {};
    var fs = bv.fontSize && byId[bv.fontSize.id], lh = bv.lineHeight && byId[bv.lineHeight.id];
    if (!fs || fs.name !== s.size) p4.push(s.name + ': tamaño no atado a ' + s.size);
    if (!lh || lh.name !== s.lineHeight) p4.push(s.name + ': interlineado no atado a ' + s.lineHeight);
  });
  check(plan.type.styles.length + ' Text Styles atados a sus variables de tamaño e interlineado', p4);
  return checks;
}

// ---------------------------------------------------------------------------
// COMPONENTES — leer el sistema, validar specs, construir y verificar.
// Los componentes se atan directo a los semánticos (sin capa de componente).
// ---------------------------------------------------------------------------
var COMP_MARK = 'ds-copilot';

// Lee lo que hay en el archivo: primitivos, semánticos con sus valores en claro y oscuro, Text Styles.
async function readSystem() {
  var colls = await figma.variables.getLocalVariableCollectionsAsync();
  var prim = colls.filter(function (c) { return c.name === COLLECTIONS.primitives; })[0];
  var sem = colls.filter(function (c) { return c.name === COLLECTIONS.semantic; })[0];
  if (!prim || !sem) return null;
  var all = await figma.variables.getLocalVariablesAsync();
  var byId = {}; all.forEach(function (v) { byId[v.id] = v; });
  var pm = prim.modes[0].modeId;
  var mode = {}; sem.modes.forEach(function (m) { mode[m.name] = m.modeId; });
  var sys = { colors: {}, semantics: {}, space: {}, radius: {}, textStyles: {}, other: {} };
  all.forEach(function (v) {
    if (v.variableCollectionId === prim.id) {
      var val = v.valuesByMode[pm];
      if (v.resolvedType === 'COLOR' && val && val.r != null) sys.colors[v.name] = toHex(val);
      else if (/^Space\//.test(v.name)) sys.space[v.name] = val;
      else if (/^Radius\//.test(v.name)) sys.radius[v.name] = val;
      else sys.other[v.name] = val;
    } else if (v.variableCollectionId === sem.id && v.resolvedType === 'COLOR') {
      var s = { description: v.description };
      MODES.forEach(function (m) {
        var a = v.valuesByMode[mode[m]];
        if (a && a.type === 'VARIABLE_ALIAS' && byId[a.id]) s[m.toLowerCase()] = byId[a.id].name;
      });
      sys.semantics[v.name] = s;
    }
  });
  (await figma.getLocalTextStylesAsync()).forEach(function (t) {
    sys.textStyles[t.name] = { family: t.fontName.family, style: t.fontName.style, size: t.fontSize, lineHeight: t.lineHeight.unit === 'PIXELS' ? t.lineHeight.value : null };
  });
  var existing = [];
  for (var i = 0; i < figma.root.children.length; i++) {
    var p = figma.root.children[i];
    await p.loadAsync();
    p.findAllWithCriteria({ types: ['COMPONENT_SET', 'COMPONENT'] }).forEach(function (n) {
      if (n.getSharedPluginData('dscopilot', 'mark')) existing.push(n.name);
    });
  }
  sys.existingComponents = existing;
  return sys;
}

// Hex de un semántico (existente o nuevo) en un modo.
function semHex(sys, plan, name, mode) {
  var s = sys.semantics[name];
  if (!s && plan) (plan.newSemantics || []).forEach(function (n) { if (n.name === name) s = n; });
  if (!s) return null;
  return sys.colors[s[mode]] || null;
}

var COMP_REQUIRED = {
  button: ['background', 'content', 'border'],
  field: ['background', 'backgroundDisabled', 'border', 'borderFocus', 'borderError', 'borderDisabled', 'label', 'value', 'placeholder', 'helper', 'error', 'valueDisabled', 'icon'],
  selection: ['background', 'border', 'borderDisabled', 'checkedBackground', 'checkedBackgroundDisabled', 'checkmark', 'label', 'labelDisabled']
};

// Valida la spec de un paso de componentes contra el sistema real del archivo.
function validateComponentStep(step, p, sys) {
  var errors = [], warnings = [], passed = [];
  var semNames = Object.keys(sys.semantics).concat((p.newSemantics || []).map(function (n) { return n.name; }));
  var hasSem = function (n) { return semNames.indexOf(n) >= 0; };
  function needSem(n, where) { if (n === 'none') return true; if (!hasSem(n)) { errors.push(where + ': el token «' + n + '» no existe en el sistema'); return false; } return true; }
  function needVar(n, map, kind, where) { if (map[n] == null) { errors.push(where + ': «' + n + '» no es un ' + kind + ' del sistema (' + Object.keys(map).join(', ') + ')'); return false; } return true; }
  function needStyle(n, where) { if (!sys.textStyles[n]) { errors.push(where + ': el Text Style «' + n + '» no existe (' + Object.keys(sys.textStyles).join(', ') + ')'); return false; } return true; }
  var checks = 0, fails = 0;
  function pair(fg, bg, need, where, level) {
    if (!fg || !bg || fg === 'none' || bg === 'none') return;
    ['light', 'dark'].forEach(function (m) {
      var a = semHex(sys, p, fg, m), b = semHex(sys, p, bg, m);
      if (!a || !b) return;
      checks++;
      var r = Math.round(contrast(a, b) * 100) / 100;
      if (r < need) { fails++; (level === 'warn' ? warnings : errors).push(where + ' (' + (m === 'light' ? 'claro' : 'oscuro') + '): ' + fg.replace('color/', '') + ' sobre ' + bg.replace('color/', '') + ' da ' + r + ':1, necesita ' + need + ':1'); }
    });
  }

  // Semánticos nuevos que propone el paso
  (p.newSemantics || []).forEach(function (n) {
    if (!NAME_RULES.semantic.test(n.name)) errors.push('Semántico nuevo con nombre fuera de convención: ' + n.name);
    if (sys.semantics[n.name]) errors.push('El semántico ' + n.name + ' ya existe: usalo en vez de crearlo de nuevo');
    ['light', 'dark'].forEach(function (m) { if (!sys.colors[n[m]]) errors.push(n.name + ' (' + m + ') apunta a «' + n[m] + '», que no es un primitivo del sistema'); });
    if (!n.description || n.description.length < 8) errors.push(n.name + ' sin descripción');
  });

  var page = 'color/background/primary', card = 'color/background/secondary';
  if (step === 'button') {
    var b = p.button || {};
    var styles = b.styles || [], sizes = b.sizes || [];
    if (!styles.length) errors.push('Falta al menos un estilo de botón');
    if (!sizes.length) errors.push('Falta al menos un tamaño de botón');
    needVar(b.radius, sys.radius, 'radio', 'Radio del botón');
    styles.forEach(function (st) {
      if (!/^[A-Z][A-Za-z]+$/.test(st.name || '')) errors.push('Nombre de estilo inválido: «' + st.name + '» (una palabra, ej. Primary)');
      ['default', 'hover', 'disabled'].forEach(function (state) {
        var t = st[state] || {};
        COMP_REQUIRED.button.forEach(function (k) { if (!t[k]) errors.push(st.name + '/' + state + ': falta ' + k); else needSem(t[k], st.name + '/' + state + '.' + k); });
      });
      var d = st.default || {}, h = st.hover || {};
      ['default', 'hover'].forEach(function (state) {
        var t = st[state] || {};
        if (t.background && t.background !== 'none') pair(t.content, t.background, 4.5, 'Botón ' + st.name + ' ' + state);
        else { pair(t.content, page, 4.5, 'Botón ' + st.name + ' ' + state); pair(t.content, card, 4.5, 'Botón ' + st.name + ' ' + state + ' sobre tarjeta'); }
      });
      if (d.background === 'none' && d.border === 'none') warnings.push('Botón ' + st.name + ': sin fondo ni borde, solo se distingue por el color del texto');
      if (d.background === 'none' && d.border !== 'none') pair(d.border, page, 3, 'Borde del botón ' + st.name, 'warn');
      if (d.background !== 'none') pair(d.background, page, 3, 'Fondo del botón ' + st.name + ' contra la página', 'warn');
      ['light', 'dark'].forEach(function (m) {
        var same = ['background', 'content', 'border'].every(function (k) { return semHex(sys, p, d[k], m) === semHex(sys, p, h[k], m); });
        if (same && d.background) errors.push('Botón ' + st.name + ': el hover se ve igual al estado normal en ' + (m === 'light' ? 'claro' : 'oscuro'));
      });
    });
    sizes.forEach(function (sz) {
      if (['S', 'M', 'L'].indexOf(sz.name) < 0) errors.push('Tamaño de botón inválido: «' + sz.name + '» (S, M o L)');
      if (!(sz.height % 4 === 0 && sz.height >= 24 && sz.height <= 64)) errors.push('Botón ' + sz.name + ': alto ' + sz.height + ' (múltiplo de 4, entre 24 y 64)');
      if (sz.height < 40 && sz.name !== 'S') warnings.push('Botón ' + sz.name + ': ' + sz.height + 'px es chico para tocar en pantallas táctiles (sugerido 40 o más)');
      needVar(sz.paddingX, sys.space, 'espaciado', 'Botón ' + sz.name + ' padding');
      needVar(sz.gap, sys.space, 'espaciado', 'Botón ' + sz.name + ' separación ícono-texto');
      needStyle(sz.textStyle, 'Botón ' + sz.name);
      if ([12, 16, 20, 24].indexOf(sz.iconSize) < 0) errors.push('Botón ' + sz.name + ': ícono de ' + sz.iconSize + 'px (12, 16, 20 o 24)');
    });
    if (!errors.length) passed.push(styles.length + ' estilos × ' + sizes.length + ' tamaños × 3 estados, todos con tokens del sistema');
  } else if (step === 'field') {
    var f = p.field || {}, t = f.tokens || {};
    COMP_REQUIRED.field.forEach(function (k) { if (!t[k]) errors.push('Campos: falta el token ' + k); else needSem(t[k], 'Campos.' + k); });
    needVar(f.paddingX, sys.space, 'espaciado', 'Padding horizontal');
    needVar(f.paddingY, sys.space, 'espaciado', 'Padding vertical (textarea)');
    needVar(f.gap, sys.space, 'espaciado', 'Separación label-campo');
    needVar(f.radius, sys.radius, 'radio', 'Radio de los campos');
    ['labelStyle', 'valueStyle', 'helperStyle'].forEach(function (k) { needStyle(f[k], 'Campos.' + k); });
    if (!(f.height % 4 === 0 && f.height >= 32 && f.height <= 64)) errors.push('Alto de campo ' + f.height + ' (múltiplo de 4, entre 32 y 64)');
    if (!(f.textareaHeight % 4 === 0 && f.textareaHeight >= f.height * 2)) errors.push('Alto de textarea ' + f.textareaHeight + ' (múltiplo de 4, al menos el doble del input)');
    if ([1, 1.5, 2].indexOf(f.borderWidth) < 0) errors.push('Borde de ' + f.borderWidth + 'px (1, 1.5 o 2)');
    if (!(f.focusBorderWidth >= f.borderWidth && f.focusBorderWidth <= 3)) errors.push('Borde en foco de ' + f.focusBorderWidth + 'px (igual o mayor que el normal, máximo 3)');
    // WCAG 1.4.11: el borde de un campo tiene que distinguirse 3:1 del fondo que lo rodea
    pair(t.border, page, 3, 'Borde del campo contra la página');
    pair(t.border, card, 3, 'Borde del campo sobre tarjeta');
    pair(t.borderFocus, page, 3, 'Borde en foco');
    pair(t.borderError, page, 3, 'Borde de error');
    pair(t.value, t.background, 4.5, 'Texto escrito');
    pair(t.placeholder, t.background, 4.5, 'Placeholder', 'warn');
    pair(t.label, page, 4.5, 'Label');
    pair(t.helper, page, 4.5, 'Texto de ayuda');
    pair(t.error, page, 4.5, 'Mensaje de error');
    pair(t.icon, t.background, 3, 'Ícono del select');
    if (t.border && t.borderFocus && t.border === t.borderFocus && f.focusBorderWidth === f.borderWidth) errors.push('El foco se ve igual que el estado normal: cambiá el color o el grosor del borde');
    if (!errors.length) passed.push('Input, select y textarea en 4 estados, con tokens del sistema');
  } else if (step === 'selection') {
    var s = p.selection || {}, ts = s.tokens || {};
    COMP_REQUIRED.selection.forEach(function (k) { if (!ts[k]) errors.push('Selección: falta el token ' + k); else needSem(ts[k], 'Selección.' + k); });
    if ([16, 20, 24].indexOf(s.size) < 0) errors.push('Tamaño de checkbox ' + s.size + ' (16, 20 o 24)');
    needVar(s.checkboxRadius, sys.radius, 'radio', 'Radio del checkbox');
    needVar(s.gap, sys.space, 'espaciado', 'Separación control-label');
    needStyle(s.labelStyle, 'Label de selección');
    if ([1, 1.5, 2].indexOf(s.borderWidth) < 0) errors.push('Borde de ' + s.borderWidth + 'px (1, 1.5 o 2)');
    if (sys.radius[s.checkboxRadius] > s.size / 3) warnings.push('Con ese radio el checkbox se parece a un radio button');
    pair(ts.border, page, 3, 'Borde del checkbox sin marcar');
    pair(ts.border, card, 3, 'Borde del checkbox sobre tarjeta');
    pair(ts.checkedBackground, page, 3, 'Checkbox marcado contra la página');
    pair(ts.checkmark, ts.checkedBackground, 3, 'Tilde sobre el checkbox marcado');
    pair(ts.label, page, 4.5, 'Label');
    if (!errors.length) passed.push('Checkbox y radio, marcados y sin marcar, normal y deshabilitado');
  }
  if (checks) passed.push((checks - fails) + ' de ' + checks + ' pares de contraste pasan en claro y oscuro');
  if ((p.newSemantics || []).length) passed.push(plural2(p.newSemantics.length, 'semántico nuevo', 'semánticos nuevos') + ' para el sistema');
  return { errors: errors, warnings: warnings, passed: passed };
}
function plural2(n, a, b) { return n + ' ' + (n === 1 ? a : b); }

// ---------------------------------------------------------------------------
// Construcción de componentes
// ---------------------------------------------------------------------------
var ICONS = {
  'Icon/Plus': '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8 3.5V12.5M3.5 8H12.5" stroke="#000" stroke-width="1.5" stroke-linecap="round"/></svg>',
  'Icon/Chevron Down': '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 6L8 10L12 6" stroke="#000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  'Icon/Check': '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.5 8.5L6.5 11.5L12.5 4.5" stroke="#000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>'
};

async function buildComponents(plan, log) {
  var warnings = [];
  var colls = await figma.variables.getLocalVariableCollectionsAsync();
  var sem = colls.filter(function (c) { return c.name === COLLECTIONS.semantic; })[0];
  var prim = colls.filter(function (c) { return c.name === COLLECTIONS.primitives; })[0];
  if (!sem || !prim) throw new Error('Este archivo no tiene las colecciones Primitives y Semantic. Construí primero las fundaciones.');
  var all = await figma.variables.getLocalVariablesAsync();
  var V = {};
  all.forEach(function (v) { if (v.variableCollectionId === sem.id || v.variableCollectionId === prim.id) V[v.name] = v; });
  var lightId = sem.modes.filter(function (m) { return m.name === 'Light'; })[0].modeId;
  var darkId = sem.modes.filter(function (m) { return m.name === 'Dark'; })[0].modeId;

  log('Agregando los semánticos nuevos…');
  var newSems = [].concat(plan.button.newSemantics || [], plan.field.newSemantics || [], plan.selection.newSemantics || []);
  newSems.forEach(function (n) {
    if (V[n.name]) return;
    var v = figma.variables.createVariable(n.name, sem, 'COLOR');
    v.setValueForMode(lightId, figma.variables.createVariableAlias(V[n.light]));
    v.setValueForMode(darkId, figma.variables.createVariableAlias(V[n.dark]));
    v.scopes = scopesFor(n.name);
    v.description = n.description || '';
    V[n.name] = v;
  });

  var styles = {};
  (await figma.getLocalTextStylesAsync()).forEach(function (t) { styles[t.name] = t; });
  for (var k in styles) { try { await figma.loadFontAsync(styles[k].fontName); } catch (e) { /* se avisa al usar */ } }
  var labelFont = await loadFirstFont([{ family: 'Inter', style: 'Semi Bold' }, { family: 'Inter', style: 'Bold' }, { family: 'Inter', style: 'Regular' }]);
  var bodyFont = await loadFirstFont([{ family: 'Inter', style: 'Regular' }]);

  // Página: se reemplaza lo que el plugin creó antes (marcado con pluginData).
  log('Preparando la página Componentes…');
  var page = figma.root.children.filter(function (p) { return p.name === 'Componentes'; })[0];
  if (page) {
    await page.loadAsync();
    page.children.slice().forEach(function (n) { if (n.getSharedPluginData('dscopilot', 'mark')) n.remove(); });
  } else { page = figma.createPage(); page.name = 'Componentes'; }

  function fill(name) { return name && name !== 'none' && V[name] ? [boundFill(V[name])] : []; }
  function bindRadius(node, name) { ['topLeftRadius', 'topRightRadius', 'bottomLeftRadius', 'bottomRightRadius'].forEach(function (f) { node.setBoundVariable(f, V[name]); }); }
  function bindPad(node, x, y) {
    if (x) { node.setBoundVariable('paddingLeft', V[x]); node.setBoundVariable('paddingRight', V[x]); }
    if (y) { node.setBoundVariable('paddingTop', V[y]); node.setBoundVariable('paddingBottom', V[y]); }
  }
  async function text(chars, styleName, colorName, name) {
    var t = figma.createText();
    var st = styles[styleName];
    if (st) { await figma.loadFontAsync(st.fontName); t.fontName = st.fontName; t.characters = chars; await t.setTextStyleIdAsync(st.id); }
    else { t.fontName = bodyFont; t.characters = chars; warnings.push('No encontré el Text Style ' + styleName); }
    t.fills = fill(colorName);
    t.name = name || 'Text';
    return t;
  }
  function mark(n) { n.setSharedPluginData('dscopilot', 'mark', '1'); return n; }
  function recolor(inst, colorName) {
    inst.findAll(function (n) { return n.type === 'VECTOR'; }).forEach(function (vec) { vec.strokes = fill(colorName); });
  }

  log('Creando íconos base…');
  var icons = {}, ix = 0;
  Object.keys(ICONS).forEach(function (name) {
    var fr = figma.createNodeFromSvg(ICONS[name]);
    var c = figma.createComponentFromNode(fr);
    c.name = name; c.description = 'Ícono base creado por DS Copilot. Reemplazalo por tu set de íconos.';
    page.appendChild(c); mark(c);
    c.x = ix; c.y = -80; ix += 32;
    icons[name] = c;
  });

  var sets = [], y = 0;
  async function title(t, sub) {
    var h = figma.createText(); h.fontName = labelFont; h.fontSize = 20; h.characters = t;
    h.fills = [{ type: 'SOLID', color: { r: 0.13, g: 0.14, b: 0.16 } }];
    page.appendChild(h); mark(h); h.x = 0; h.y = y; y += 32;
    if (sub) { var s = figma.createText(); s.fontName = bodyFont; s.fontSize = 12; s.characters = sub; s.fills = [{ type: 'SOLID', color: { r: 0.4, g: 0.42, b: 0.46 } }]; page.appendChild(s); mark(s); s.x = 0; s.y = y; y += 28; }
  }
  function finishSet(set, name, description, cols) {
    set.name = name; set.description = description;
    mark(set);
    // grilla con aire
    var kids = set.children.slice(), gx = 24, gy = 24, colW = 0, rowH = 0;
    kids.forEach(function (k) { colW = Math.max(colW, k.width); rowH = Math.max(rowH, k.height); });
    kids.forEach(function (k, i) { k.x = 24 + (i % cols) * (colW + gx); k.y = 24 + Math.floor(i / cols) * (rowH + gy); });
    var rows = Math.ceil(kids.length / cols);
    set.resizeWithoutConstraints(48 + cols * colW + (cols - 1) * gx, 48 + rows * rowH + (rows - 1) * gy);
    set.fills = [{ type: 'SOLID', color: { r: 1, g: 1, b: 1 } }];
    set.strokes = [{ type: 'SOLID', color: { r: 0.592, g: 0.278, b: 1 } }]; set.dashPattern = [6, 4]; set.strokeWeight = 1; set.cornerRadius = 8;
    set.x = 0; set.y = y; y += set.height + 64;
    sets.push(set);
    return set;
  }

  // ---- Botón ----
  log('Construyendo Button…');
  await title('Button', 'Estilos × tamaños × estados. Propiedades: Label y Show icon.');
  var B = plan.button.button, comps = [], labelRefs = [], iconRefs = [];
  for (var si = 0; si < B.styles.length; si++) {
    var st = B.styles[si];
    for (var zi = 0; zi < B.sizes.length; zi++) {
      var sz = B.sizes[zi];
      var states = [['Default', st.default], ['Hover', st.hover], ['Disabled', st.disabled]];
      for (var ti = 0; ti < states.length; ti++) {
        var tk = states[ti][1];
        var c = figma.createComponent();
        c.resize(120, sz.height);
        c.layoutMode = 'HORIZONTAL';
        c.primaryAxisSizingMode = 'AUTO'; c.counterAxisSizingMode = 'FIXED';
        c.primaryAxisAlignItems = 'CENTER'; c.counterAxisAlignItems = 'CENTER';
        bindPad(c, sz.paddingX, null);
        c.setBoundVariable('itemSpacing', V[sz.gap]);
        bindRadius(c, B.radius);
        c.fills = fill(tk.background);
        if (tk.border && tk.border !== 'none') { c.strokes = fill(tk.border); c.strokeWeight = B.borderWidth || 1; c.strokeAlign = 'INSIDE'; }
        var ic = icons['Icon/Plus'].createInstance(); ic.name = 'Icon';
        ic.resize(sz.iconSize, sz.iconSize); recolor(ic, tk.content); ic.visible = false;
        c.appendChild(ic);
        var lb = await text('Button', sz.textStyle, tk.content, 'Label');
        c.appendChild(lb);
        c.name = 'Style=' + st.name + ', Size=' + sz.name + ', State=' + states[ti][0];
        page.appendChild(c);
        comps.push(c); labelRefs.push(lb); iconRefs.push(ic);
      }
    }
  }
  var bset = figma.combineAsVariants(comps, page);
  var kLabel = bset.addComponentProperty('Label', 'TEXT', 'Button');
  var kIcon = bset.addComponentProperty('Show icon', 'BOOLEAN', false);
  labelRefs.forEach(function (n) { n.componentPropertyReferences = { characters: kLabel }; });
  iconRefs.forEach(function (n) { n.componentPropertyReferences = { visible: kIcon }; });
  finishSet(bset, 'Button', plan.button.button.description || 'Botón del sistema.', 3);

  // ---- Campos: Input, Select, Textarea ----
  var F = plan.field.field, T = F.tokens;
  var fieldStates = [
    ['Default', { bg: T.background, border: T.border, value: T.value, ph: T.placeholder, helper: T.helper, w: F.borderWidth }],
    ['Focus', { bg: T.background, border: T.borderFocus, value: T.value, ph: T.placeholder, helper: T.helper, w: F.focusBorderWidth }],
    ['Error', { bg: T.background, border: T.borderError, value: T.value, ph: T.placeholder, helper: T.error, w: F.borderWidth }],
    ['Disabled', { bg: T.backgroundDisabled, border: T.borderDisabled, value: T.valueDisabled, ph: T.valueDisabled, helper: T.helper, w: F.borderWidth }]
  ];
  var kinds = [['Input', 'Campo de texto de una línea.'], ['Select', 'Desplegable cerrado. El menú abierto queda para una próxima versión.'], ['Textarea', 'Campo de texto de varias líneas.']];
  for (var ki = 0; ki < kinds.length; ki++) {
    var kind = kinds[ki][0];
    log('Construyendo ' + kind + '…');
    await title(kind, 'Estado × contenido. Propiedades: Label, Text y Show helper.');
    var fcomps = [], refs = { label: [], text: [], helper: [] };
    for (var fi = 0; fi < fieldStates.length; fi++) {
      var fs = fieldStates[fi];
      for (var ci = 0; ci < 2; ci++) {
        var filled = ci === 1;
        var c2 = figma.createComponent();
        c2.resize(320, 100);
        c2.layoutMode = 'VERTICAL'; c2.primaryAxisSizingMode = 'AUTO'; c2.counterAxisSizingMode = 'FIXED';
        c2.setBoundVariable('itemSpacing', V[F.gap]);
        c2.fills = [];
        var lab = await text('Label', F.labelStyle, fs[1] === fieldStates[3][1] ? T.valueDisabled : T.label, 'Label');
        c2.appendChild(lab); lab.layoutSizingHorizontal = 'FILL'; lab.textAutoResize = 'HEIGHT';
        var box = figma.createFrame(); box.name = 'Field';
        var h = kind === 'Textarea' ? F.textareaHeight : F.height;
        box.resize(320, h);
        box.layoutMode = 'HORIZONTAL'; box.primaryAxisSizingMode = 'FIXED'; box.counterAxisSizingMode = 'FIXED';
        box.counterAxisAlignItems = kind === 'Textarea' ? 'MIN' : 'CENTER';
        box.itemSpacing = 8;
        bindPad(box, F.paddingX, kind === 'Textarea' ? F.paddingY : null);
        bindRadius(box, F.radius);
        box.fills = fill(fs[1].bg);
        box.strokes = fill(fs[1].border); box.strokeWeight = fs[1].w; box.strokeAlign = 'INSIDE';
        c2.appendChild(box); box.layoutSizingHorizontal = 'FILL';
        var val = await text(filled ? 'Texto ingresado' : 'Placeholder', F.valueStyle, filled ? fs[1].value : fs[1].ph, 'Text');
        box.appendChild(val); val.layoutSizingHorizontal = 'FILL'; val.textAutoResize = 'HEIGHT';
        if (kind === 'Select') {
          var chev = icons['Icon/Chevron Down'].createInstance(); chev.name = 'Chevron';
          recolor(chev, fs[0] === 'Disabled' ? T.valueDisabled : T.icon);
          box.appendChild(chev);
        }
        var help = await text(fs[0] === 'Error' ? 'Mensaje de error' : 'Texto de ayuda', F.helperStyle, fs[1].helper, 'Helper');
        c2.appendChild(help); help.layoutSizingHorizontal = 'FILL'; help.textAutoResize = 'HEIGHT';
        c2.name = 'State=' + fs[0] + ', Content=' + (filled ? 'Filled' : 'Placeholder');
        page.appendChild(c2);
        fcomps.push(c2); refs.label.push(lab); refs.text.push(val); refs.helper.push(help);
      }
    }
    var fset = figma.combineAsVariants(fcomps, page);
    var kL = fset.addComponentProperty('Label', 'TEXT', 'Label');
    var kH = fset.addComponentProperty('Show helper', 'BOOLEAN', true);
    refs.label.forEach(function (n) { n.componentPropertyReferences = { characters: kL }; });
    refs.helper.forEach(function (n) { n.componentPropertyReferences = { visible: kH }; });
    finishSet(fset, kind, kinds[ki][1], 2);
  }

  // ---- Checkbox y Radio ----
  var S = plan.selection.selection, TS = S.tokens;
  var selKinds = ['Checkbox', 'Radio'];
  for (var ri = 0; ri < selKinds.length; ri++) {
    var sk = selKinds[ri];
    log('Construyendo ' + sk + '…');
    await title(sk, 'Marcado × estado. Propiedad: Label.');
    var scomps = [], slabels = [];
    var combos = [[false, 'Default'], [true, 'Default'], [false, 'Disabled'], [true, 'Disabled']];
    for (var qi = 0; qi < combos.length; qi++) {
      var checked = combos[qi][0], dis = combos[qi][1] === 'Disabled';
      var c3 = figma.createComponent();
      c3.layoutMode = 'HORIZONTAL'; c3.primaryAxisSizingMode = 'AUTO'; c3.counterAxisSizingMode = 'AUTO';
      c3.counterAxisAlignItems = 'CENTER';
      c3.setBoundVariable('itemSpacing', V[S.gap]);
      c3.fills = [];
      var bx = figma.createFrame(); bx.name = 'Control';
      bx.resize(S.size, S.size);
      bx.layoutMode = 'HORIZONTAL'; bx.primaryAxisSizingMode = 'FIXED'; bx.counterAxisSizingMode = 'FIXED';
      bx.primaryAxisAlignItems = 'CENTER'; bx.counterAxisAlignItems = 'CENTER';
      if (sk === 'Checkbox') bindRadius(bx, S.checkboxRadius); else bx.cornerRadius = S.size / 2;
      var onBg = dis ? TS.checkedBackgroundDisabled : TS.checkedBackground;
      if (checked) {
        bx.fills = fill(onBg);
        if (sk === 'Checkbox') {
          var ck = icons['Icon/Check'].createInstance(); ck.name = 'Check';
          ck.resize(S.size * 0.75, S.size * 0.75); recolor(ck, dis ? TS.labelDisabled : TS.checkmark); bx.appendChild(ck);
        } else {
          var dot = figma.createEllipse(); dot.name = 'Dot';
          dot.resize(Math.round(S.size * 0.4), Math.round(S.size * 0.4)); dot.fills = fill(dis ? TS.labelDisabled : TS.checkmark); bx.appendChild(dot);
        }
      } else {
        bx.fills = fill(TS.background);
        bx.strokes = fill(dis ? TS.borderDisabled : TS.border); bx.strokeWeight = S.borderWidth; bx.strokeAlign = 'INSIDE';
      }
      c3.appendChild(bx);
      var sl = await text(sk === 'Checkbox' ? 'Acepto los términos' : 'Opción', S.labelStyle, dis ? TS.labelDisabled : TS.label, 'Label');
      c3.appendChild(sl);
      c3.name = 'Checked=' + (checked ? 'True' : 'False') + ', State=' + combos[qi][1];
      page.appendChild(c3);
      scomps.push(c3); slabels.push(sl);
    }
    var sset = figma.combineAsVariants(scomps, page);
    var kS = sset.addComponentProperty('Label', 'TEXT', sk === 'Checkbox' ? 'Acepto los términos' : 'Opción');
    slabels.forEach(function (n) { n.componentPropertyReferences = { characters: kS }; });
    finishSet(sset, sk, sk === 'Checkbox' ? 'Casilla de verificación con label.' : 'Opción única dentro de un grupo.', 4);
  }

  // ---- Vista en claro y oscuro: un formulario de ejemplo armado con instancias ----
  log('Armando el formulario de ejemplo en claro y oscuro…');
  function defaultOf(set) { return set.defaultVariant || set.children[0]; }
  function pick(set, props) {
    return set.children.filter(function (v) { return Object.keys(props).every(function (k) { return v.variantProperties[k] === props[k]; }); })[0] || defaultOf(set);
  }
  var byName = {}; sets.forEach(function (s) { byName[s.name] = s; });
  var demoRow = figma.createFrame(); demoRow.name = 'Ejemplo · claro y oscuro';
  demoRow.layoutMode = 'HORIZONTAL'; demoRow.primaryAxisSizingMode = 'AUTO'; demoRow.counterAxisSizingMode = 'AUTO';
  demoRow.itemSpacing = 32; demoRow.fills = [];
  page.appendChild(demoRow); mark(demoRow);
  ['Claro', 'Oscuro'].forEach(function (lbl) {
    var card = figma.createFrame(); card.name = lbl;
    card.layoutMode = 'VERTICAL'; card.primaryAxisSizingMode = 'AUTO'; card.counterAxisSizingMode = 'FIXED';
    card.resize(384, 100); card.itemSpacing = 20;
    card.paddingTop = card.paddingBottom = card.paddingLeft = card.paddingRight = 32;
    card.cornerRadius = 16; card.fills = fill('color/background/primary');
    if (lbl === 'Oscuro') card.setExplicitVariableModeForCollection(sem, darkId);
    var parts = [
      pick(byName.Input, { State: 'Default', Content: 'Filled' }).createInstance(),
      pick(byName.Select, { State: 'Focus', Content: 'Placeholder' }).createInstance(),
      pick(byName.Textarea, { State: 'Error', Content: 'Filled' }).createInstance(),
      pick(byName.Checkbox, { Checked: 'True', State: 'Default' }).createInstance(),
      pick(byName.Radio, { Checked: 'True', State: 'Default' }).createInstance()
    ];
    var btn = pick(byName.Button, { Style: B.styles[0].name, Size: (B.sizes.filter(function (z) { return z.name === 'M'; })[0] || B.sizes[0]).name, State: 'Default' }).createInstance();
    parts.push(btn);
    parts.forEach(function (n, i) { card.appendChild(n); if (i < 3 || n === btn) n.layoutSizingHorizontal = 'FILL'; });
    demoRow.appendChild(card);
  });
  demoRow.x = Math.max.apply(null, sets.map(function (s) { return s.width; })) + 120; demoRow.y = 0;

  await figma.setCurrentPageAsync(page);
  figma.viewport.scrollAndZoomIntoView(page.children);
  return { warnings: warnings, pageId: page.id };
}

// ---------------------------------------------------------------------------
// Verificación de componentes: lee lo construido y lo compara con la spec
// ---------------------------------------------------------------------------
async function verifyComponents(plan) {
  var checks = [];
  function check(label, problems) { checks.push({ label: label, ok: problems.length === 0, problems: problems.slice(0, 8) }); }
  var sys = await readSystem();
  var all = await figma.variables.getLocalVariablesAsync();
  var byId = {}; all.forEach(function (v) { byId[v.id] = v; });
  var tstyles = {}; (await figma.getLocalTextStylesAsync()).forEach(function (t) { tstyles[t.id] = t.name; });
  var page = figma.root.children.filter(function (p) { return p.name === 'Componentes'; })[0];
  if (!page) { check('Página «Componentes»', ['No existe']); return checks; }
  await page.loadAsync();
  var sets = {}; page.findAllWithCriteria({ types: ['COMPONENT_SET'] }).forEach(function (s) { if (s.getSharedPluginData('dscopilot', 'mark')) sets[s.name] = s; });
  function varName(paints) { var p = paints && paints[0]; var b = p && p.boundVariables && p.boundVariables.color; return b ? (byId[b.id] || {}).name : (p ? 'sin variable' : 'none'); }
  function bound(node, field) { var b = node.boundVariables && node.boundVariables[field]; b = Array.isArray(b) ? b[0] : b; return b ? (byId[b.id] || {}).name : null; }
  function child(node, name) { return node.findOne(function (n) { return n.name === name; }); }
  function contrastIssues(fgName, bgName, need, where, out) {
    ['light', 'dark'].forEach(function (m) {
      var a = semHex(sys, null, fgName, m), b = semHex(sys, null, bgName, m);
      if (a && b && contrast(a, b) < need) out.push(where + ' en ' + (m === 'light' ? 'claro' : 'oscuro') + ': ' + (Math.round(contrast(a, b) * 100) / 100) + ':1');
    });
  }

  // Semánticos nuevos
  var newSems = [].concat(plan.button.newSemantics || [], plan.field.newSemantics || [], plan.selection.newSemantics || []);
  if (newSems.length) check(newSems.length + ' semánticos nuevos creados y apuntando a primitivos', newSems.filter(function (n) { return !sys.semantics[n.name] || sys.semantics[n.name].light !== n.light || sys.semantics[n.name].dark !== n.dark; }).map(function (n) { return n.name; }));

  // Botón
  var B = plan.button.button, bs = sets.Button, p1 = [], c1 = [];
  if (!bs) p1.push('Falta el componente Button');
  else {
    var exp = B.styles.length * B.sizes.length * 3;
    if (bs.children.length !== exp) p1.push('Tiene ' + bs.children.length + ' variantes, se esperaban ' + exp);
    B.styles.forEach(function (st) {
      B.sizes.forEach(function (sz) {
        [['Default', st.default], ['Hover', st.hover], ['Disabled', st.disabled]].forEach(function (pair) {
          var v = bs.children.filter(function (k) { return k.name === 'Style=' + st.name + ', Size=' + sz.name + ', State=' + pair[0]; })[0];
          var tag = st.name + '/' + sz.name + '/' + pair[0];
          if (!v) return p1.push('Falta ' + tag);
          var tk = pair[1];
          if (varName(v.fills) !== (tk.background === 'none' ? 'none' : tk.background)) p1.push(tag + ': fondo ' + varName(v.fills) + ', se aprobó ' + tk.background);
          if (tk.border !== 'none' && varName(v.strokes) !== tk.border) p1.push(tag + ': borde ' + varName(v.strokes));
          var lb = child(v, 'Label');
          if (!lb || varName(lb.fills) !== tk.content) p1.push(tag + ': texto ' + (lb ? varName(lb.fills) : 'faltante'));
          if (lb && tstyles[lb.textStyleId] !== sz.textStyle) p1.push(tag + ': Text Style ' + (tstyles[lb.textStyleId] || 'ninguno'));
          if (bound(v, 'paddingLeft') !== sz.paddingX) p1.push(tag + ': padding no atado a ' + sz.paddingX);
          if (bound(v, 'topLeftRadius') !== B.radius) p1.push(tag + ': radio no atado a ' + B.radius);
          if (Math.round(v.height) !== sz.height) p1.push(tag + ': alto ' + Math.round(v.height) + ', se aprobó ' + sz.height);
          if (pair[0] !== 'Disabled') contrastIssues(tk.content, tk.background === 'none' ? 'color/background/primary' : tk.background, 4.5, tag, c1);
        });
      });
    });
    var props = Object.keys(bs.componentPropertyDefinitions);
    if (!props.some(function (k) { return k.indexOf('Label') === 0; }) || !props.some(function (k) { return k.indexOf('Show icon') === 0; })) p1.push('Faltan las propiedades Label o Show icon');
  }
  check('Button: variantes, tokens, Text Styles y espaciado como se aprobó', p1);

  // Campos
  var F = plan.field.field, T = F.tokens, p2 = [];
  ['Input', 'Select', 'Textarea'].forEach(function (kind) {
    var s = sets[kind];
    if (!s) return p2.push('Falta ' + kind);
    if (s.children.length !== 8) p2.push(kind + ': ' + s.children.length + ' variantes, se esperaban 8');
    var expected = { Default: T.border, Focus: T.borderFocus, Error: T.borderError, Disabled: T.borderDisabled };
    s.children.forEach(function (v) {
      var state = v.variantProperties.State, box = child(v, 'Field');
      if (!box) return p2.push(kind + ' ' + v.name + ': falta el campo');
      if (varName(box.strokes) !== expected[state]) p2.push(kind + ' ' + state + ': borde ' + varName(box.strokes) + ', se aprobó ' + expected[state]);
      if (bound(box, 'paddingLeft') !== F.paddingX) p2.push(kind + ' ' + state + ': padding no atado');
      if (bound(box, 'topLeftRadius') !== F.radius) p2.push(kind + ' ' + state + ': radio no atado');
      var t = child(v, 'Text');
      if (t && tstyles[t.textStyleId] !== F.valueStyle) p2.push(kind + ' ' + state + ': Text Style del texto');
    });
  });
  check('Input, Select y Textarea: 4 estados con los bordes y tokens aprobados', p2);
  var c2 = [];
  contrastIssues(T.border, 'color/background/primary', 3, 'Borde del campo', c2);
  contrastIssues(T.value, T.background, 4.5, 'Texto escrito', c2);
  contrastIssues(T.error, 'color/background/primary', 4.5, 'Mensaje de error', c2);

  // Selección
  var S = plan.selection.selection, TS = S.tokens, p3 = [];
  ['Checkbox', 'Radio'].forEach(function (kind) {
    var s = sets[kind];
    if (!s) return p3.push('Falta ' + kind);
    if (s.children.length !== 4) p3.push(kind + ': ' + s.children.length + ' variantes, se esperaban 4');
    s.children.forEach(function (v) {
      var on = v.variantProperties.Checked === 'True', dis = v.variantProperties.State === 'Disabled';
      var ctl = child(v, 'Control');
      if (!ctl) return p3.push(kind + ': falta el control');
      var expBg = on ? (dis ? TS.checkedBackgroundDisabled : TS.checkedBackground) : TS.background;
      if (varName(ctl.fills) !== expBg) p3.push(kind + ' ' + v.name + ': fondo ' + varName(ctl.fills));
      if (Math.round(ctl.width) !== S.size) p3.push(kind + ': tamaño ' + Math.round(ctl.width));
    });
  });
  check('Checkbox y Radio: marcado y deshabilitado con los tokens aprobados', p3);
  var c3 = [];
  contrastIssues(TS.border, 'color/background/primary', 3, 'Borde sin marcar', c3);
  contrastIssues(TS.checkmark, TS.checkedBackground, 3, 'Tilde sobre marcado', c3);
  check('Contraste medido sobre los valores reales, en claro y oscuro', c1.concat(c2, c3));
  return checks;
}

// ---------------------------------------------------------------------------
// Documentación: lectura del sistema para el export estático.
// Solo lee. Devuelve un snapshot (Variables con su cadena de alias y valores por modo,
// Text Styles, component sets con sus bindings) y una imagen PNG de cada set.
// ---------------------------------------------------------------------------
var DOCS = (function () {
  function hex(c) {
    function h(x) { return ('0' + Math.round(x * 255).toString(16)).slice(-2).toUpperCase(); }
    return '#' + h(c.r) + h(c.g) + h(c.b) + (c.a !== undefined && c.a < 1 ? '/' + c.a.toFixed(2) : '');
  }
  function slug(s) {
    var v = String(s).toLowerCase(), from = 'áàäâéèëêíìïîóòöôúùüûñç', to = 'aaaaeeeeiiiioooouuuunc';
    for (var i = 0; i < from.length; i++) v = v.split(from[i]).join(to[i]);
    return v.replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'componente';
  }
  function progress(text) { figma.ui.postMessage({ type: 'docsProgress', text: text }); }
  var COLOR = function () { return null; }, MODES = ['light'];

  // ---- medición para Anatomía y Accesibilidad (datos, no opiniones)
  function paintColor(node, key) {
    var ps = node[key];
    if (!Array.isArray(ps)) return null;
    var p = ps.filter(function (x) { return x.type === 'SOLID' && x.visible !== false && (x.opacity == null || x.opacity > 0.5); })[0];
    if (!p) return null;
    var out = {};
    MODES.forEach(function (m) { out[m] = p.boundVariables && p.boundVariables.color ? COLOR(p.boundVariables.color.id, m) : hex(p.color); });
    return out[MODES[0]] ? out : null;
  }
  function propName(id) { return String(id || '').split('#')[0]; }
  function anatomyOf(root) {
    var out = [];
    function walk(n, depth) {
      if (out.length >= 30 || depth > 4) return;
      (n.children || []).forEach(function (c) {
        var refs = c.componentPropertyReferences || {};
        var kind = c.type === 'TEXT' ? 'texto' : c.type === 'INSTANCE' ? (Math.max(c.width, c.height) <= 32 ? 'ícono' : 'instancia') :
          (c.type === 'FRAME' || c.type === 'GROUP') ? 'contenedor' : 'forma';
        out.push({ name: c.name, kind: kind, depth: depth, optional: refs.visible ? propName(refs.visible) : '', editable: refs.characters ? propName(refs.characters) : '',
          swap: refs.mainComponent ? propName(refs.mainComponent) : '', hidden: c.visible === false });
        if (c.type !== 'INSTANCE') walk(c, depth + 1);
      });
    }
    walk(root, 1);
    return out;
  }
  function a11yOf(variant) {
    var pairs = [], seen = {};
    function walk(n, bg) {
      if (n.visible === false) return;
      var own = n.type === 'TEXT' ? null : paintColor(n, 'fills');
      var here = own || bg;
      if (n.type === 'TEXT' && !seen[n.name]) {
        var fg = paintColor(n, 'fills');
        var size = typeof n.fontSize === 'number' ? n.fontSize : n.getRangeFontSize(0, 1);
        var font = typeof n.fontName === 'object' && n.fontName.style ? n.fontName : n.getRangeFontName(0, 1);
        if (fg) { pairs.push({ layer: n.name, kind: 'texto', fg: fg, bg: here, size: size, bold: /bold|semi|black|heavy/i.test(font.style || '') }); seen[n.name] = 1; }
        return;
      }
      if (n.type === 'INSTANCE') {
        if (seen[n.name]) return;
        var vec = n.findOne(function (x) { return (x.type === 'VECTOR' || x.type === 'ELLIPSE' || x.type === 'BOOLEAN_OPERATION') && ((x.strokes && x.strokes.length) || (x.fills && x.fills.length)); });
        var ic = vec ? (paintColor(vec, 'strokes') || paintColor(vec, 'fills')) : null;
        if (ic) { pairs.push({ layer: n.name, kind: 'ícono', fg: ic, bg: here, size: Math.round(n.width) }); seen[n.name] = 1; }
        return;
      }
      (n.children || []).forEach(function (c) { walk(c, here); });
    }
    walk(variant, null);
    return { variant: variant.name, w: Math.round(variant.width), h: Math.round(variant.height), pairs: pairs };
  }


  async function readVariables() {
    var cols = await figma.variables.getLocalVariableCollectionsAsync();
    var colById = {};
    cols.forEach(function (c) { colById[c.id] = c; });
    function layerOf(c, i) {
      var n = c.name.toLowerCase();
      if (n.indexOf('primitiv') >= 0) return 'P';
      if (n.indexOf('semant') >= 0) return 'S';
      if (n.indexOf('component') >= 0) return 'C';
      return ['P', 'S', 'C'][Math.min(i, 2)];
    }
    var layer = {};
    cols.forEach(function (c, i) { layer[c.id] = layerOf(c, i); });
    var vars = await figma.variables.getLocalVariablesAsync();
    var byId = {};
    vars.forEach(function (v) { byId[v.id] = v; });
    function fmt(val) { return val && typeof val === 'object' && 'r' in val ? hex(val) : val; }
    // Resuelve en un modo: si la colección destino tiene un modo con el mismo nombre lo usa; si no, el primero.
    function resolve(v, modeName) {
      var cur = v;
      for (var g = 0; g < 10; g++) {
        var c = colById[cur.variableCollectionId];
        var m = c.modes.filter(function (x) { return x.name === modeName; })[0] || c.modes[0];
        var r = cur.valuesByMode[m.modeId];
        if (r && r.type === 'VARIABLE_ALIAS') { cur = byId[r.id]; if (!cur) return null; } else return fmt(r);
      }
      return null;
    }
    var rows = vars.map(function (v) {
      var c = colById[v.variableCollectionId];
      var first = v.valuesByMode[c.modes[0].modeId];
      var alias = first && first.type === 'VARIABLE_ALIAS' ? (byId[first.id] ? byId[first.id].name : null) : null;
      var row = [layer[v.variableCollectionId], v.name, v.resolvedType[0], alias, resolve(v, c.modes[0].name), v.description || ''];
      if (c.modes.length > 1) {
        var modes = {};
        c.modes.forEach(function (m) {
          var r = v.valuesByMode[m.modeId];
          modes[m.name] = { aliasOf: r && r.type === 'VARIABLE_ALIAS' && byId[r.id] ? byId[r.id].name : null, resolved: resolve(v, m.name) };
        });
        row.push(modes);
      }
      return row;
    });
    // Para medir contraste: color de una Variable en modo claro u oscuro.
    var hasDark = cols.some(function (c) { return c.modes.some(function (m) { return /dark|oscuro/i.test(m.name); }); });
    function modeFor(col, want) {
      var re = want === 'dark' ? /dark|oscuro/i : /light|claro/i;
      return col.modes.filter(function (m) { return re.test(m.name); })[0] || col.modes[0];
    }
    COLOR = function (id, want) {
      var cur = byId[id];
      for (var g = 0; g < 10 && cur; g++) {
        var r = cur.valuesByMode[modeFor(colById[cur.variableCollectionId], want).modeId];
        if (r && r.type === 'VARIABLE_ALIAS') { cur = byId[r.id]; continue; }
        return r && 'r' in r ? hex(r) : null;
      }
      return null;
    };
    MODES = hasDark ? ['light', 'dark'] : ['light'];
    return {
      collections: cols.map(function (c) { return [layer[c.id], c.name]; }),
      modes: cols.map(function (c) { return [c.name, c.modes.map(function (m) { return m.name; })]; }),
      vars: rows
    };
  }

  async function readTextStyles() {
    var styles = await figma.getLocalTextStylesAsync();
    return styles.map(function (s) {
      var lh = s.lineHeight.unit === 'PIXELS' ? s.lineHeight.value : s.lineHeight.unit;
      return [s.name, s.fontName.family, s.fontName.style, s.fontSize, lh, Object.keys(s.boundVariables || {}).length > 0];
    });
  }

  async function readSet(s, withImage) {
    var ids = new Set(), styleIds = new Set();
    var nodes = [s].concat(s.findAll(function () { return true; }));
    for (var i = 0; i < nodes.length; i++) {
      var n = nodes[i];
      var bv = n.boundVariables || {};
      for (var k in bv) {
        var x = bv[k];
        (Array.isArray(x) ? x : [x]).forEach(function (a) { if (a && a.id) ids.add(a.id); });
      }
      ['fills', 'strokes'].forEach(function (key) {
        if (key in n && Array.isArray(n[key])) n[key].forEach(function (p) { if (p.boundVariables && p.boundVariables.color) ids.add(p.boundVariables.color.id); });
      });
      if (n.type === 'TEXT' && typeof n.textStyleId === 'string' && n.textStyleId) styleIds.add(n.textStyleId);
    }
    var boundVars = [], textStyles = [];
    for (var id of ids) { var v = await figma.variables.getVariableByIdAsync(id); if (v) boundVars.push(v.name); }
    for (var sid of styleIds) { var st = await figma.getStyleByIdAsync(sid); if (st) textStyles.push(st.name); }
    var props = s.type === 'COMPONENT_SET'
      ? Object.keys(s.componentPropertyDefinitions).map(function (key) {
          var d = s.componentPropertyDefinitions[key];
          return key.split('#')[0] + ':' + d.type + (d.variantOptions ? '[' + d.variantOptions.join('|') + ']' : '');
        })
      : [];
    var image = null;
    if (withImage) { try { image = await s.exportAsync({ format: 'PNG', constraint: { type: 'SCALE', value: 2 } }); } catch (e) { image = null; } }
    var variantsNodes = s.type === 'COMPONENT_SET' ? s.children.slice(0, 48) : [s];
    var first = s.type === 'COMPONENT_SET' ? (s.defaultVariant || s.children[0]) : s;
    var measure = null;
    try { measure = { anatomy: anatomyOf(first), variants: variantsNodes.map(a11yOf), modes: MODES }; } catch (e) { measure = null; }
    return {
      set: { name: s.name, id: s.id, variants: s.type === 'COMPONENT_SET' ? s.children.length : 1, props: props, measure: measure,
        createdInPlugin: !!s.getSharedPluginData('dscopilot', 'custom'),
        description: s.description || '', boundVars: boundVars.sort(), textStyles: textStyles.sort(), size: [Math.round(s.width), Math.round(s.height)] },
      image: image
    };
  }

  // Un componente = un component set (o un componente suelto con properties).
  // Los sets cuyo nombre empieza con el de otro ("Button Icon-Secondary" → "Button") se documentan juntos.
  // Los componentes sueltos sin properties (íconos, logos) se listan aparte.
  async function readComponents(withImages) {
    var found = [], assets = [], images = {};
    var pages = figma.root.children;
    for (var i = 0; i < pages.length; i++) {
      var page = pages[i];
      progress('Leyendo la página «' + page.name + '» (' + (i + 1) + ' de ' + pages.length + ')…');
      await page.loadAsync();
      page.findAllWithCriteria({ types: ['COMPONENT_SET', 'COMPONENT'] }).forEach(function (n) {
        if (n.type === 'COMPONENT' && n.parent && n.parent.type === 'COMPONENT_SET') return;
        // pieza suelta = componente sin propiedades y chico o llamado Icon/… (íconos, logos); una composición sin propiedades sigue siendo componente
        var loose = n.type === 'COMPONENT' && Object.keys(n.componentPropertyDefinitions || {}).length === 0 && (/^icon[\/ ]/i.test(n.name) || Math.max(n.width, n.height) <= 48);
        if (loose) assets.push({ name: n.name, id: n.id, page: page.name, size: [Math.round(n.width), Math.round(n.height)] });
        else found.push({ node: n, page: page.name });
      });
    }
    var byLength = found.slice().sort(function (a, b) { return a.node.name.length - b.node.name.length; });
    var groups = [], groupOf = {};
    byLength.forEach(function (f) {
      var name = f.node.name;
      var base = groups.filter(function (g) { return name.indexOf(g.name + ' ') === 0 || name.indexOf(g.name + '/') === 0; })[0];
      if (base) { base.items.push(f); groupOf[f.node.id] = base; }
      else { var g = { name: name, page: f.page, items: [f] }; groups.push(g); groupOf[f.node.id] = g; }
    });
    var ordered = [];
    found.forEach(function (f) { var g = groupOf[f.node.id]; if (ordered.indexOf(g) < 0) ordered.push(g); });
    var components = [], used = {};
    for (var j = 0; j < ordered.length; j++) {
      var g = ordered[j];
      progress('Leyendo ' + g.name + ' (' + (j + 1) + ' de ' + ordered.length + ')…');
      var sets = [];
      g.items.sort(function (a, b) { return found.indexOf(a) - found.indexOf(b); });
      for (var k = 0; k < g.items.length; k++) {
        var r = await readSet(g.items[k].node, withImages);
        sets.push(r.set);
        if (r.image) images[g.items[k].node.id] = r.image;
      }
      var s = slug(g.name), n2 = 2;
      while (used[s]) s = slug(g.name) + '-' + n2++;
      used[s] = true;
      components.push({ slug: s, name: g.name, page: g.page, sets: sets });
    }
    return { components: components, assets: assets, images: images };
  }

  async function scan(withImages) {
    progress('Leyendo Variables…');
    var v = await readVariables();
    var textStyles = await readTextStyles();
    var c = await readComponents(withImages !== false);
    return {
      snapshot: {
        schema: 'ds-copilot/snapshot@0.2',
        source: { fileKey: figma.fileKey || null, fileName: figma.root.name, readAt: new Date().toISOString().slice(0, 10) },
        collections: v.collections, modes: v.modes,
        varColumns: ['collection', 'name', 'type', 'aliasOf', 'resolved', 'description', 'modes?'],
        vars: v.vars, textStyles: textStyles, components: c.components, assets: c.assets
      },
      images: c.images
    };
  }

  return { scan: scan };
})();

// ---------------------------------------------------------------------------
// Componentes por conversación: núcleo compartido (interfaz y Figma).
// Una especificación describe cualquier componente: capas (árbol plano), ejes de variantes,
// propiedades, overrides por variante y tokens. Acá viven la validación, la resolución de
// cada variante y la biblioteca de íconos. No toca Figma.
// ---------------------------------------------------------------------------
var SPEC = (function () {
  var ICONS = {
    'Icon/Check': '<path d="M20 6L9 17l-5-5"/>',
    'Icon/Close': '<path d="M18 6L6 18M6 6l12 12"/>',
    'Icon/Plus': '<path d="M12 5v14M5 12h14"/>',
    'Icon/Minus': '<path d="M5 12h14"/>',
    'Icon/Chevron Down': '<path d="M6 9l6 6 6-6"/>',
    'Icon/Chevron Up': '<path d="M6 15l6-6 6 6"/>',
    'Icon/Chevron Right': '<path d="M9 6l6 6-6 6"/>',
    'Icon/Chevron Left': '<path d="M15 6l-6 6 6 6"/>',
    'Icon/Arrow Right': '<path d="M5 12h14M13 6l6 6-6 6"/>',
    'Icon/Info': '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>',
    'Icon/Alert Circle': '<circle cx="12" cy="12" r="9"/><path d="M12 7v6M12 16.5h.01"/>',
    'Icon/Alert Triangle': '<path d="M10.3 3.9L1.8 18a2 2 0 001.7 3h17a2 2 0 001.7-3L13.7 3.9a2 2 0 00-3.4 0zM12 9v4M12 17h.01"/>',
    'Icon/Alert Octagon': '<path d="M7.9 2h8.2L22 7.9v8.2L16.1 22H7.9L2 16.1V7.9zM12 8v4M12 16h.01"/>',
    'Icon/Check Circle': '<circle cx="12" cy="12" r="9"/><path d="M8 12l3 3 5-6"/>',
    'Icon/Search': '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
    'Icon/Bell': '<path d="M6 8a6 6 0 0112 0c0 7 3 9 3 9H3s3-2 3-9M10.3 21a1.9 1.9 0 003.4 0"/>',
    'Icon/User': '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0116 0"/>',
    'Icon/Star': '<path d="M12 3l2.9 5.9 6.5.9-4.7 4.6 1.1 6.5L12 17.8l-5.8 3.1 1.1-6.5-4.7-4.6 6.5-.9z"/>',
    'Icon/Circle': '<circle cx="12" cy="12" r="9"/>',
    'Icon/Dot': '<circle cx="12" cy="12" r="3"/>'
  };
  function iconSvg(name, size, color) {
    return '<svg xmlns="http://www.w3.org/2000/svg" width="' + (size || 24) + '" height="' + (size || 24) + '" viewBox="0 0 24 24" fill="none" stroke="' + (color || '#000') +
      '" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + (ICONS[name] || ICONS['Icon/Circle']) + '</svg>';
  }

  // ---- color
  function rgb(hex) { var h = String(hex || '').replace('#', '').slice(0, 6); return { r: parseInt(h.slice(0, 2), 16) / 255, g: parseInt(h.slice(2, 4), 16) / 255, b: parseInt(h.slice(4, 6), 16) / 255 }; }
  function lum(hex) { var c = rgb(hex); function l(v) { return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); } return 0.2126 * l(c.r) + 0.7152 * l(c.g) + 0.0722 * l(c.b); }
  function contrast(a, b) { var x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); }

  // Hex de un token de color en un modo ('light' | 'dark'). Acepta semánticos, nuevos semánticos y primitivos.
  function hexOf(sys, spec, name, mode) {
    if (!name) return null;
    var s = sys.semantics[name];
    if (!s && spec) (spec.newSemantics || []).forEach(function (n) { if (n.name === name) s = n; });
    if (s) return sys.colors[s[mode]] || sys.colors[s.light] || null;
    return sys.colors[name] || null;
  }
  function isColor(sys, spec, name) {
    return !!(sys.semantics[name] || sys.colors[name] || (spec.newSemantics || []).some(function (n) { return n.name === name; }));
  }

  // ---- variantes
  function combos(axes) {
    var out = [{}];
    (axes || []).forEach(function (a) {
      var next = [];
      out.forEach(function (c) { a.values.forEach(function (v) { var o = {}; for (var k in c) o[k] = c[k]; o[a.name] = v; next.push(o); }); });
      out = next;
    });
    return out;
  }
  function variantName(axes, v) { return (axes || []).map(function (a) { return a.name + '=' + v[a.name]; }).join(', '); }
  function matches(when, v) { return (when || []).every(function (w) { return v[w.axis] === w.value; }); }
  var OVERRIDABLE = ['fill', 'stroke', 'color', 'visible', 'icon', 'content', 'opacity'];
  // Capas efectivas de una variante: base + overrides que aplican, en orden.
  function resolve(spec, v) {
    var byName = {}, list = (spec.layers || []).map(function (l) {
      var o = {}; for (var k in l) o[k] = l[k];
      o.visible = true; o.opacity = 1;
      byName[o.name] = o; return o;
    });
    (spec.overrides || []).forEach(function (ov) {
      if (!matches(ov.when, v) || !byName[ov.layer]) return;
      var L = byName[ov.layer];
      if (ov.property === 'visible') L.visible = ov.value !== 'false';
      else if (ov.property === 'opacity') L.opacity = parseFloat(ov.value);
      else L[ov.property] = ov.value;
    });
    (spec.booleans || []).forEach(function (b) { if (byName[b.layer] && !b.default) byName[b.layer].hiddenByDefault = true; });
    return { list: list, byName: byName };
  }
  function children(list, name) { return list.filter(function (l) { return l.parent === name; }); }
  function root(list) { return list.filter(function (l) { return !l.parent; })[0]; }

  // Fondo efectivo detrás de una capa: el fill del ancestro más cercano, o el fondo de página.
  function bgBehind(R, layer, sys) {
    var p = layer.parent ? R.byName[layer.parent] : null;
    while (p) { if (p.fill) return p.fill; p = p.parent ? R.byName[p.parent] : null; }
    return sys.pageBackground;
  }
  function textSize(sys, styleName) { var t = sys.textStyles[styleName]; return t ? t.size : 14; }
  function textBold(sys, styleName) { var t = sys.textStyles[styleName]; return t ? /bold|semi|black|heavy/i.test(t.style) : false; }

  // ---- validación: errores bloquean la construcción, advertencias no.
  function validate(spec, sys) {
    var errors = [], warnings = [], passed = [];
    var layers = spec.layers || [], names = {};
    if (!/^[A-Z][A-Za-z0-9]*( [A-Z][A-Za-z0-9]*)*$/.test(spec.name || '')) errors.push('Nombre de componente inválido: «' + spec.name + '» (en inglés, con mayúscula inicial, ej. Tooltip o Stepper Step)');
    var clash = (sys.components || []).filter(function (c) { return c.name === spec.name && !c.ours; })[0];
    if (clash) errors.push('Ya existe un componente «' + spec.name + '» en el archivo que no creó esta conversación. Elegí otro nombre para no pisarlo.');
    else if ((sys.components || []).some(function (c) { return c.name === spec.name && c.ours; })) warnings.push('Ya creaste un «' + spec.name + '» antes: al construir se reemplaza.');
    if (!spec.description || spec.description.length < 12) errors.push('Falta la descripción del componente');

    // capas
    layers.forEach(function (l) {
      if (names[l.name]) errors.push('Hay dos capas llamadas «' + l.name + '»');
      names[l.name] = l;
    });
    var roots = layers.filter(function (l) { return !l.parent; });
    if (roots.length !== 1) errors.push('Tiene que haber exactamente una capa raíz (sin parent); hay ' + roots.length);
    else if (roots[0].kind !== 'frame') errors.push('La capa raíz tiene que ser un frame');
    layers.forEach(function (l) {
      var where = 'Capa «' + l.name + '»';
      if (l.parent && !names[l.parent]) errors.push(where + ': su parent «' + l.parent + '» no existe');
      if (l.parent && names[l.parent] && names[l.parent].kind !== 'frame') errors.push(where + ': solo un frame puede tener capas adentro');
      if (l.kind === 'frame') {
        if (l.gap && sys.space[l.gap] == null) errors.push(where + ': el espaciado «' + l.gap + '» no existe');
        if (l.paddingX && sys.space[l.paddingX] == null) errors.push(where + ': el espaciado «' + l.paddingX + '» no existe');
        if (l.paddingY && sys.space[l.paddingY] == null) errors.push(where + ': el espaciado «' + l.paddingY + '» no existe');
      }
      if (l.radius && sys.radius[l.radius] == null) errors.push(where + ': el radio «' + l.radius + '» no existe');
      if (l.fill && !isColor(sys, spec, l.fill)) errors.push(where + ': el color «' + l.fill + '» no es un token del sistema');
      if (l.stroke && !isColor(sys, spec, l.stroke)) errors.push(where + ': el color «' + l.stroke + '» no es un token del sistema');
      if (l.fill && sys.colors[l.fill]) warnings.push(where + ': usa el primitivo «' + l.fill + '» directo; conviene un semántico');
      if (l.kind === 'text') {
        if (!sys.textStyles[l.textStyle]) errors.push(where + ': el Text Style «' + l.textStyle + '» no existe');
        if (!l.color || !isColor(sys, spec, l.color)) errors.push(where + ': falta un color de texto válido');
        if (!l.content) errors.push(where + ': falta el texto de ejemplo');
      }
      if (l.kind === 'icon') {
        if ((sys.icons || []).indexOf(l.icon) < 0) errors.push(where + ': el ícono «' + l.icon + '» no está disponible');
        if ([12, 16, 20, 24, 32].indexOf(l.size) < 0) errors.push(where + ': ícono de ' + l.size + 'px (12, 16, 20, 24 o 32)');
        if (!l.color || !isColor(sys, spec, l.color)) errors.push(where + ': falta un color de ícono válido');
      }
      if (l.kind === 'shape') {
        if (!(l.size > 0 && l.size <= 64)) errors.push(where + ': tamaño de forma ' + l.size + ' (entre 1 y 64)');
        if (!l.fill && !l.stroke) errors.push(where + ': una forma necesita relleno o borde');
      }
      ['width', 'height'].forEach(function (k) {
        var v = l[k];
        if (v && v !== 'hug' && v !== 'fill') {
          var n = Number(v);
          if (!(n > 0)) errors.push(where + ': ' + k + ' «' + v + '» (hug, fill o un número)');
          else if (n % 4) warnings.push(where + ': ' + k + ' de ' + n + 'px fuera de la grilla de 4');
          if (k === 'width' && v === 'fill' && !l.parent) errors.push(where + ': la raíz no puede ser fill; usá hug o un ancho fijo');
        }
      });
    });

    // ejes, propiedades y overrides
    var axes = spec.axes || [], axisNames = {};
    axes.forEach(function (a) {
      if (!/^[A-Z][A-Za-z ]*$/.test(a.name)) errors.push('Eje con nombre inválido: «' + a.name + '»');
      if (axisNames[a.name]) errors.push('Eje repetido: ' + a.name);
      axisNames[a.name] = a;
      if (!a.values || a.values.length < 2) errors.push('El eje ' + a.name + ' necesita al menos dos valores');
      (a.values || []).forEach(function (v) { if (!/^[A-Z0-9][A-Za-z0-9]*$/.test(v)) errors.push('Valor inválido en ' + a.name + ': «' + v + '» (una palabra, con mayúscula)'); });
    });
    var count = combos(axes).length;
    if (count > 48) errors.push(count + ' variantes es demasiado: reducí ejes o valores (máximo 48)');
    (spec.booleans || []).forEach(function (b) { if (!names[b.layer]) errors.push('La propiedad «' + b.name + '» apunta a una capa que no existe: ' + b.layer); });
    (spec.texts || []).forEach(function (t) { if (!names[t.layer] || names[t.layer].kind !== 'text') errors.push('La propiedad de texto «' + t.name + '» tiene que apuntar a una capa de texto'); });
    (spec.overrides || []).forEach(function (ov) {
      if (!names[ov.layer]) errors.push('Override sobre una capa que no existe: ' + ov.layer);
      if (OVERRIDABLE.indexOf(ov.property) < 0) errors.push('Override de una propiedad no permitida: ' + ov.property);
      (ov.when || []).forEach(function (w) { if (!axisNames[w.axis] || axisNames[w.axis].values.indexOf(w.value) < 0) errors.push('Override con condición inválida: ' + w.axis + '=' + w.value); });
      if ((ov.property === 'fill' || ov.property === 'stroke' || ov.property === 'color') && ov.value && !isColor(sys, spec, ov.value)) errors.push('Override de ' + ov.layer + ': «' + ov.value + '» no es un token de color');
      if (ov.property === 'icon' && (sys.icons || []).indexOf(ov.value) < 0) errors.push('Override de ' + ov.layer + ': el ícono «' + ov.value + '» no está disponible');
    });

    // semánticos nuevos
    (spec.newSemantics || []).forEach(function (n) {
      if (sys.semantics[n.name]) errors.push('El semántico ' + n.name + ' ya existe: usalo en vez de crearlo');
      if (sys.semanticPattern && !new RegExp(sys.semanticPattern).test(n.name)) errors.push('Semántico nuevo con nombre fuera de la convención del sistema: ' + n.name + ' (ej. ' + sys.semanticExample + ')');
      ['light', 'dark'].forEach(function (m) { if (!sys.colors[n[m]]) errors.push(n.name + ' (' + m + ') apunta a «' + n[m] + '», que no es un primitivo del sistema'); });
      if (!n.description || n.description.length < 8) errors.push(n.name + ' sin descripción');
    });

    // composición
    var comp = spec.composition || {};
    if (comp.enabled) {
      if (!/^[A-Z][A-Za-z0-9 ]*$/.test(comp.name || '') || comp.name === spec.name) errors.push('La composición necesita un nombre propio distinto del componente (ej. Stepper para Stepper Step)');
      if (!comp.items || comp.items.length < 2) errors.push('La composición necesita al menos dos elementos');
      if (comp.gap && sys.space[comp.gap] == null) errors.push('Composición: el espaciado «' + comp.gap + '» no existe');
      (comp.items || []).forEach(function (it, i) {
        (it.variant || []).forEach(function (w) { if (!axisNames[w.axis] || axisNames[w.axis].values.indexOf(w.value) < 0) errors.push('Composición, elemento ' + (i + 1) + ': variante inválida ' + w.axis + '=' + w.value); });
        (it.texts || []).forEach(function (t) { if (!(spec.texts || []).some(function (x) { return x.name === t.prop; })) errors.push('Composición, elemento ' + (i + 1) + ': la propiedad de texto «' + t.prop + '» no existe'); });
      });
    }

    // contraste, variante por variante, en claro y oscuro (los tokens inválidos ya están reportados y se saltean)
    if (roots.length === 1) {
      var checks = 0, fails = 0;
      combos(axes).forEach(function (v) {
        var R = resolve(spec, v), vn = variantName(axes, v) || spec.name;
        R.list.forEach(function (l) {
          if (!l.visible) return;
          var fg = l.kind === 'text' || l.kind === 'icon' ? l.color : null;
          if (!fg) return;
          var bg = bgBehind(R, l, sys);
          var need = l.kind === 'icon' ? 3 : (textSize(sys, l.textStyle) >= 18 || (textSize(sys, l.textStyle) >= 14 && textBold(sys, l.textStyle)) ? 3 : 4.5);
          ['light', 'dark'].forEach(function (m) {
            var a = hexOf(sys, spec, fg, m), b = hexOf(sys, spec, bg, m);
            if (!a || !b) return;
            checks++;
            var ratio = Math.round(contrast(a, b) * 100) / 100;
            if (ratio < need) { fails++; (l.opacity < 1 ? warnings : errors).push(vn + ' · ' + l.name + ' (' + (m === 'light' ? 'claro' : 'oscuro') + '): ' + ratio + ':1, necesita ' + need + ':1'); }
          });
        });
      });
      if (checks) passed.push((checks - fails) + ' de ' + checks + ' pares de contraste pasan en claro y oscuro');
      if (!errors.length) passed.push(plural(count, 'variante', 'variantes') + ', todas con tokens del sistema');
    }
    if ((spec.newSemantics || []).length) passed.push(plural(spec.newSemantics.length, 'semántico nuevo', 'semánticos nuevos') + ' para el sistema');
    return { errors: errors, warnings: warnings, passed: passed };
  }
  function plural(n, a, b) { return n + ' ' + (n === 1 ? a : b); }

  // ---- tokens de componente (para sistemas con colección de componente).
  // Por cada capa y propiedad: si el token no cambia entre variantes → {C}/{capa}/{prop};
  // si lo explica un solo eje → {C}/{capa}/{prop}/{valor}; si no, la combinación completa.
  function slug(s) { return String(s).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, ''); }
  function componentTokenPlan(spec) {
    var axes = spec.axes || [], vs = combos(axes), plan = {}, list = [];
    var rootName = (root(spec.layers || []) || {}).name;
    (spec.layers || []).forEach(function (l) {
      ['fill', 'stroke', 'color'].forEach(function (prop) {
        var per = vs.map(function (v) { var R = resolve(spec, v); return R.byName[l.name][prop] || ''; });
        if (per.every(function (x) { return !x; })) return;
        var role = prop === 'fill' ? (l.kind === 'text' || l.kind === 'icon' ? 'color' : 'background') : prop === 'stroke' ? 'border' : (l.kind === 'icon' ? 'icon' : 'text');
        var seg = l.name === rootName ? '' : slug(l.name);
        var base = spec.name + '/' + (seg && seg !== role ? seg + '/' : '') + role;
        var distinct = per.filter(function (x, i) { return x && per.indexOf(x) === i; });
        var keyAxis = null;
        if (distinct.length > 1) {
          axes.some(function (a) {
            var map = {}, ok = true;
            vs.forEach(function (v, i) { if (!per[i]) return; if (map[v[a.name]] && map[v[a.name]] !== per[i]) ok = false; map[v[a.name]] = per[i]; });
            if (ok) keyAxis = a.name;
            return ok;
          });
        }
        vs.forEach(function (v, i) {
          if (!per[i]) return;
          var name = distinct.length === 1 ? base : base + '/' + (keyAxis ? slug(v[keyAxis]) : axes.map(function (a) { return slug(v[a.name]); }).join('-'));
          plan[variantName(axes, v) + '|' + l.name + '|' + prop] = name;
          if (!list.some(function (t) { return t.name === name; })) list.push({ name: name, target: per[i], kind: prop });
        });
      });
    });
    return { byKey: plan, tokens: list };
  }

  return { ICONS: ICONS, iconSvg: iconSvg, contrast: contrast, hexOf: hexOf, combos: combos, variantName: variantName, resolve: resolve,
    children: children, root: root, validate: validate, componentTokenPlan: componentTokenPlan, slug: slug, bgBehind: bgBehind };
})();

// ---------------------------------------------------------------------------
// Componentes por conversación: lado Figma (leer el sistema, construir, verificar).
// Funciona con el sistema que arma este plugin (Primitives / Semantic, claro y oscuro)
// y con sistemas propios de tres capas (primitivos, semánticos y, si existe, componente).
// ---------------------------------------------------------------------------
var CUSTOM = (function () {
  var MARK = 'custom';

  function hx(c) { function h(x) { return ('0' + Math.round(x * 255).toString(16)).slice(-2).toUpperCase(); } return '#' + h(c.r) + h(c.g) + h(c.b); }
  function layerOf(c, i) {
    var n = c.name.toLowerCase();
    if (n.indexOf('primitiv') >= 0) return 'P';
    if (n.indexOf('semant') >= 0) return 'S';
    if (n.indexOf('component') >= 0) return 'C';
    return ['P', 'S', 'C'][Math.min(i, 2)];
  }

  async function context() {
    var cols = await figma.variables.getLocalVariableCollectionsAsync();
    var vars = await figma.variables.getLocalVariablesAsync();
    var byId = {}, colOf = {}, ctx = { prim: null, sem: null, comp: null, vars: vars, byName: {} };
    vars.forEach(function (v) { byId[v.id] = v; });
    cols.forEach(function (c, i) { var L = layerOf(c, i); colOf[c.id] = L; if (L === 'P' && !ctx.prim) ctx.prim = c; if (L === 'S' && !ctx.sem) ctx.sem = c; if (L === 'C' && !ctx.comp) ctx.comp = c; });
    vars.forEach(function (v) {
      var L = colOf[v.variableCollectionId];
      // un nombre puede repetirse entre colecciones: gana la capa más baja que lo define
      if (!ctx.byName[v.name] || (L === 'S' && colOf[ctx.byName[v.name].variableCollectionId] === 'C') || L === 'P') ctx.byName[v.name] = v;
    });
    ctx.byId = byId; ctx.colOf = colOf;
    return ctx;
  }

  function modeIdFor(col, want) {
    var m = col.modes.filter(function (x) { return x.name.toLowerCase() === want; })[0];
    if (!m && want === 'light') m = col.modes[0];
    return m ? m.modeId : null;
  }

  // Lo que la conversación necesita saber del sistema real del archivo.
  async function readSystem() {
    var ctx = await context();
    if (!ctx.sem) return null;
    var sys = { colors: {}, semantics: {}, space: {}, radius: {}, textStyles: {}, icons: Object.keys(SPEC.ICONS), components: [],
      hasComponentLayer: !!ctx.comp, modes: ctx.sem.modes.map(function (m) { return m.name; }) };
    function resolveIn(v, modeId) {
      for (var g = 0; g < 10 && v; g++) {
        var col = null;
        var val = v.valuesByMode[modeId] || v.valuesByMode[Object.keys(v.valuesByMode)[0]];
        if (val && val.type === 'VARIABLE_ALIAS') { v = ctx.byId[val.id]; modeId = null; continue; }
        return val;
      }
      return null;
    }
    ctx.vars.forEach(function (v) {
      var L = ctx.colOf[v.variableCollectionId];
      var first = v.valuesByMode[Object.keys(v.valuesByMode)[0]];
      if (L === 'P') {
        if (v.resolvedType === 'COLOR' && first && first.r != null) sys.colors[v.name] = hx(first);
        else if (v.resolvedType === 'FLOAT' && /space|spacing/i.test(v.name)) sys.space[v.name] = first;
        else if (v.resolvedType === 'FLOAT' && /radius|radii|corner/i.test(v.name)) sys.radius[v.name] = first;
      } else if (L === 'S' && v.resolvedType === 'COLOR') {
        var s = { description: v.description || '' };
        ['light', 'dark'].forEach(function (m) {
          var mid = modeIdFor(ctx.sem, m) || modeIdFor(ctx.sem, 'light');
          var a = v.valuesByMode[mid];
          if (a && a.type === 'VARIABLE_ALIAS' && ctx.byId[a.id]) {
            var t = ctx.byId[a.id];
            // si apunta a otro semántico, se sigue hasta el primitivo
            for (var g = 0; g < 6 && ctx.colOf[t.variableCollectionId] !== 'P'; g++) {
              var nx = t.valuesByMode[modeIdFor(ctx.sem, m) || Object.keys(t.valuesByMode)[0]] || t.valuesByMode[Object.keys(t.valuesByMode)[0]];
              if (!nx || nx.type !== 'VARIABLE_ALIAS') break;
              t = ctx.byId[nx.id];
            }
            s[m] = t ? t.name : null;
          }
        });
        if (s.light && !s.dark) s.dark = s.light;
        if (s.light) sys.semantics[v.name] = s;
      } else if (L === 'S' && v.resolvedType === 'FLOAT') {
        if (/space|spacing|gap|padding/i.test(v.name)) sys.space[v.name] = resolveIn(v, null);
        else if (/radius/i.test(v.name)) sys.radius[v.name] = resolveIn(v, null);
      }
    });
    var semNames = Object.keys(sys.semantics);
    sys.pageBackground = semNames.filter(function (n) { return /background\/primary$/.test(n); })[0] || semNames.filter(function (n) { return /background/.test(n); })[0] || semNames[0];
    sys.semanticExample = semNames.filter(function (n) { return /background/.test(n); })[0] || semNames[0] || 'color/background/primary';
    sys.semanticPrefix = /^color\//.test(sys.semanticExample) ? 'color/' : '';
    // como texto: los mensajes entre Figma y la interfaz no transportan expresiones regulares
    sys.semanticPattern = sys.semanticPrefix ? '^color\\/[a-z]+(\\/[a-z0-9-]+)+$' : '^[A-Za-z]+(\\/[A-Za-z0-9-]+)+$';
    (await figma.getLocalTextStylesAsync()).forEach(function (t) {
      sys.textStyles[t.name] = { family: t.fontName.family, style: t.fontName.style, size: t.fontSize, lineHeight: t.lineHeight.unit === 'PIXELS' ? t.lineHeight.value : Math.round(t.fontSize * 1.4) };
    });
    for (var i = 0; i < figma.root.children.length; i++) {
      var p = figma.root.children[i];
      await p.loadAsync();
      p.findAllWithCriteria({ types: ['COMPONENT_SET', 'COMPONENT'] }).forEach(function (n) {
        if (n.type === 'COMPONENT' && n.parent && n.parent.type === 'COMPONENT_SET') return;
        if (/^Icon\//.test(n.name)) { if (sys.icons.indexOf(n.name) < 0) sys.icons.push(n.name); return; }
        sys.components.push({ name: n.name, ours: !!n.getSharedPluginData('dscopilot', MARK), page: p.name });
      });
    }
    return sys;
  }

  // ---- construcción
  function paint(v) { return figma.variables.setBoundVariableForPaint({ type: 'SOLID', color: { r: 0, g: 0, b: 0 } }, 'color', v); }
  function scopes(kind) { return kind === 'stroke' ? ['STROKE_COLOR'] : kind === 'color' ? ['TEXT_FILL', 'SHAPE_FILL', 'STROKE_COLOR'] : ['FRAME_FILL', 'SHAPE_FILL']; }

  async function buildInner(spec, log, made) {
    var warnings = [], created = [];
    var ctx = await context();
    if (!ctx.sem) throw new Error('Este archivo no tiene una colección de semánticos. Construí primero las fundaciones.');
    var V = ctx.byName;
    function mark(n) { n.setSharedPluginData('dscopilot', MARK, spec.name); created.push(n.id); return n; }

    // 1. semánticos nuevos
    if ((spec.newSemantics || []).length) log('Agregando los semánticos nuevos…');
    (spec.newSemantics || []).forEach(function (n) {
      if (V[n.name]) return;
      var v = figma.variables.createVariable(n.name, ctx.sem, 'COLOR'); made.push(v);
      ctx.sem.modes.forEach(function (m) {
        var target = V[/dark/i.test(m.name) ? n.dark : n.light];
        if (target) v.setValueForMode(m.modeId, figma.variables.createVariableAlias(target));
      });
      v.scopes = ['ALL_FILLS', 'STROKE_COLOR'];
      v.description = n.description || '';
      V[n.name] = v;
    });

    // 2. tokens de componente, si el sistema tiene esa capa
    var compPlan = null, CT = {};
    if (ctx.comp) {
      log('Creando los tokens de ' + spec.name + '…');
      compPlan = SPEC.componentTokenPlan(spec);
      var existing = {};
      ctx.vars.forEach(function (v) { if (v.variableCollectionId === ctx.comp.id) existing[v.name] = v; });
      compPlan.tokens.forEach(function (t) {
        var v = existing[t.name];
        if (!v) { v = figma.variables.createVariable(t.name, ctx.comp, 'COLOR'); made.push(v); }
        ctx.comp.modes.forEach(function (m) { if (V[t.target]) v.setValueForMode(m.modeId, figma.variables.createVariableAlias(V[t.target])); });
        v.scopes = scopes(t.kind);
        if (!v.description) v.description = 'Creado por DS Copilot para ' + spec.name + '. Apunta a ' + t.target + '.';
        CT[t.name] = v;
      });
      var spaceTok = {};
      (spec.layers || []).forEach(function (l) {
        var base = spec.name + '/' + (l.parent ? SPEC.slug(l.name) + '/' : '');
        [['gap', 'gap'], ['paddingX', 'padding-x'], ['paddingY', 'padding-y'], ['radius', 'radius']].forEach(function (pair) {
          var target = l[pair[0]];
          if (!target || !V[target]) return;
          var name = base + pair[1];
          var v = existing[name] || CT[name];
          if (!v) { v = figma.variables.createVariable(name, ctx.comp, 'FLOAT'); made.push(v); }
          ctx.comp.modes.forEach(function (m) { v.setValueForMode(m.modeId, figma.variables.createVariableAlias(V[target])); });
          v.scopes = pair[0] === 'radius' ? ['CORNER_RADIUS'] : ['GAP'];
          if (!v.description) v.description = 'Creado por DS Copilot para ' + spec.name + '. Apunta a ' + target + '.';
          CT[name] = v; spaceTok[l.name + '|' + pair[0]] = v;
        });
      });
      compPlan.space = spaceTok;
    }
    function colorVar(vn, layer, prop, tokenName) {
      if (compPlan) { var n = compPlan.byKey[vn + '|' + layer + '|' + prop]; if (n && CT[n]) return CT[n]; }
      return V[tokenName];
    }
    function spaceVar(layer, key) {
      if (compPlan && compPlan.space[layer.name + '|' + key]) return compPlan.space[layer.name + '|' + key];
      return V[layer[key]];
    }

    // 3. íconos: se reutilizan los del archivo; los que faltan se crean en la página «Íconos»
    log('Preparando íconos…');
    var iconComps = {}, needIcons = {};
    (spec.layers || []).forEach(function (l) { if (l.kind === 'icon') needIcons[l.icon] = 1; });
    (spec.overrides || []).forEach(function (o) { if (o.property === 'icon') needIcons[o.value] = 1; });
    for (var pi = 0; pi < figma.root.children.length; pi++) {
      var pg = figma.root.children[pi];
      await pg.loadAsync();
      pg.findAllWithCriteria({ types: ['COMPONENT'] }).forEach(function (n) { if (needIcons[n.name] && !iconComps[n.name]) iconComps[n.name] = n; });
    }
    var missing = Object.keys(needIcons).filter(function (n) { return !iconComps[n]; });
    if (missing.length) {
      var ipage = figma.root.children.filter(function (p) { return p.name === 'Íconos'; })[0];
      if (!ipage) { ipage = figma.createPage(); ipage.name = 'Íconos'; made.push(ipage); }
      await ipage.loadAsync();
      var ix = ipage.children.reduce(function (m, c) { return Math.max(m, c.x + c.width + 16); }, 0);
      missing.forEach(function (name) {
        var fr = figma.createNodeFromSvg(SPEC.iconSvg(name, 24, '#000000'));
        var c = figma.createComponentFromNode(fr); made.push(c);
        c.name = name; c.description = 'Ícono creado por DS Copilot. Reemplazalo por tu set si tenés uno.';
        c.setSharedPluginData('dscopilot', 'icon', '1');
        ipage.appendChild(c); c.x = ix; c.y = 0; ix += 40;
        iconComps[name] = c;
      });
    }

    // 4. Text Styles y fuentes
    var styles = {};
    (await figma.getLocalTextStylesAsync()).forEach(function (t) { styles[t.name] = t; });
    for (var k in styles) { try { await figma.loadFontAsync(styles[k].fontName); } catch (e) { /* se avisa al usar */ } }
    var fallback = { family: 'Inter', style: 'Regular' };
    try { await figma.loadFontAsync(fallback); } catch (e) { /* sin Inter */ }

    // 5. página: la del componente; se borra lo que esta conversación creó antes con ese nombre
    log('Preparando la página ' + spec.name + '…');
    var pageName = spec.name.split(' ')[0];
    var page = figma.root.children.filter(function (p) { return p.name === pageName; })[0];
    if (page) {
      await page.loadAsync();
      page.children.slice().forEach(function (n) { var m = n.getSharedPluginData('dscopilot', MARK); if (m === spec.name || (spec.composition && spec.composition.enabled && m === spec.composition.name + '·' + spec.name)) n.remove(); });
    } else { page = figma.createPage(); page.name = pageName; made.push(page); }
    var startX = page.children.reduce(function (m, c) { return Math.max(m, c.x + c.width + 160); }, 0);

    // 6. variantes
    // Tamaño: primero los valores fijos (resize pisa los modos de sizing), después HUG / FILL.
    function size(node, l) {
      function num(v) { return v && v !== 'hug' && v !== 'fill' && Number(v) > 0; }
      var fw = num(l.width), fh = num(l.height);
      if (fw || fh) node.resize(fw ? Number(l.width) : node.width, fh ? Number(l.height) : node.height);
      var inAL = !!(node.parent && 'layoutMode' in node.parent && node.parent.layoutMode !== 'NONE');
      var isAL = !!('layoutMode' in node && node.layoutMode !== 'NONE');
      [['width', 'Horizontal', fw], ['height', 'Vertical', fh]].forEach(function (d) {
        var key = 'layoutSizing' + d[1];
        if (l[d[0]] === 'fill' && inAL) node[key] = 'FILL';
        else if (d[2]) { if (inAL || isAL) node[key] = 'FIXED'; }
        else if (isAL) node[key] = 'HUG';
      });
      if (node.type === 'TEXT') node.textAutoResize = (l.width === 'fill' || fw) ? 'HEIGHT' : 'WIDTH_AND_HEIGHT';
    }
    function bindRadius(node, v) { ['topLeftRadius', 'topRightRadius', 'bottomLeftRadius', 'bottomRightRadius'].forEach(function (f) { node.setBoundVariable(f, v); }); }
    var refs = { text: {}, bool: {} };
    async function makeNode(l, vn) {
      var node;
      if (l.kind === 'frame') {
        node = l.parent ? figma.createFrame() : figma.createComponent(); made.push(node);
        node.layoutMode = l.direction === 'row' ? 'HORIZONTAL' : 'VERTICAL';
        node.primaryAxisSizingMode = 'AUTO'; node.counterAxisSizingMode = 'AUTO';
        node.counterAxisAlignItems = l.align === 'center' ? 'CENTER' : l.align === 'end' ? 'MAX' : 'MIN';
        node.fills = l.fill && colorVar(vn, l.name, 'fill', l.fill) ? [paint(colorVar(vn, l.name, 'fill', l.fill))] : [];
        if (l.stroke && colorVar(vn, l.name, 'stroke', l.stroke)) { node.strokes = [paint(colorVar(vn, l.name, 'stroke', l.stroke))]; node.strokeWeight = l.strokeWidth || 1; node.strokeAlign = 'INSIDE'; }
        if (l.gap && spaceVar(l, 'gap')) node.setBoundVariable('itemSpacing', spaceVar(l, 'gap'));
        if (l.paddingX && spaceVar(l, 'paddingX')) { node.setBoundVariable('paddingLeft', spaceVar(l, 'paddingX')); node.setBoundVariable('paddingRight', spaceVar(l, 'paddingX')); }
        if (l.paddingY && spaceVar(l, 'paddingY')) { node.setBoundVariable('paddingTop', spaceVar(l, 'paddingY')); node.setBoundVariable('paddingBottom', spaceVar(l, 'paddingY')); }
        if (l.radius && spaceVar(l, 'radius')) bindRadius(node, spaceVar(l, 'radius'));
        node.clipsContent = false;
        node.strokesIncludedInLayout = false; // el borde no cambia el tamaño: todas las variantes miden lo mismo
      } else if (l.kind === 'text') {
        node = figma.createText(); made.push(node);
        var st = styles[l.textStyle];
        node.fontName = st ? st.fontName : fallback;
        node.characters = l.content || ' ';
        if (st) await node.setTextStyleIdAsync(st.id); else warnings.push('No encontré el Text Style ' + l.textStyle);
        var cv = colorVar(vn, l.name, 'color', l.color);
        node.fills = cv ? [paint(cv)] : [];
      } else if (l.kind === 'icon') {
        node = iconComps[l.icon].createInstance(); made.push(node);
        node.rescale(l.size / Math.max(1, node.width));
        var ic = colorVar(vn, l.name, 'color', l.color);
        if (ic) node.findAll(function (n) { return n.type === 'VECTOR' || n.type === 'ELLIPSE' || n.type === 'BOOLEAN_OPERATION'; }).forEach(function (vec) {
          if (vec.strokes && vec.strokes.length) vec.strokes = [paint(ic)];
          if (vec.fills && vec.fills.length) vec.fills = [paint(ic)];
        });
      } else {
        node = l.shape === 'circle' ? figma.createEllipse() : figma.createRectangle(); made.push(node);
        node.resize(l.size, l.size);
        node.fills = l.fill && colorVar(vn, l.name, 'fill', l.fill) ? [paint(colorVar(vn, l.name, 'fill', l.fill))] : [];
        if (l.stroke && colorVar(vn, l.name, 'stroke', l.stroke)) { node.strokes = [paint(colorVar(vn, l.name, 'stroke', l.stroke))]; node.strokeWeight = l.strokeWidth || 1; node.strokeAlign = 'INSIDE'; }
        if (node.type === 'RECTANGLE' && l.radius && spaceVar(l, 'radius')) bindRadius(node, spaceVar(l, 'radius'));
      }
      node.name = l.name;
      node.opacity = l.opacity;
      return node;
    }
    var variants = SPEC.combos(spec.axes), comps = [];
    for (var vi = 0; vi < variants.length; vi++) {
      var v = variants[vi], vn = SPEC.variantName(spec.axes, v);
      log('Construyendo ' + spec.name + (vn ? ' · ' + vn : '') + '…');
      var R = SPEC.resolve(spec, v);
      var nodes = {};
      var rootL = SPEC.root(R.list);
      // de arriba hacia abajo, para que cada hijo tenga su padre con auto layout
      var queue = [rootL];
      while (queue.length) {
        var l = queue.shift();
        var n = await makeNode(l, vn);
        nodes[l.name] = n;
        if (l.parent) { nodes[l.parent].appendChild(n); }
        size(n, l);
        n.visible = l.visible;
        SPEC.children(R.list, l.name).forEach(function (c) { queue.push(c); });
      }
      var comp = nodes[rootL.name];
      comp.name = vn || spec.name;
      (spec.texts || []).forEach(function (t) { if (nodes[t.layer]) (refs.text[t.name] = refs.text[t.name] || []).push(nodes[t.layer]); });
      (spec.booleans || []).forEach(function (b) { if (nodes[b.layer]) (refs.bool[b.name] = refs.bool[b.name] || []).push(nodes[b.layer]); });
      page.appendChild(comp);
      comps.push(comp); made.push(comp);
    }

    // 7. component set y propiedades
    var set = comps.length > 1 || (spec.axes || []).length ? figma.combineAsVariants(comps, page) : comps[0];
    set.name = spec.name; made.push(set);
    set.description = spec.description + (spec.behaviorNotes ? '\n\nComportamiento: ' + spec.behaviorNotes : '');
    var propRefs = new Map();
    function addRef(node, field, id) { var r = propRefs.get(node) || {}; r[field] = id; propRefs.set(node, r); }
    (spec.texts || []).forEach(function (t) {
      var def = ((spec.layers || []).filter(function (l) { return l.name === t.layer; })[0] || {}).content || t.name;
      var id = set.addComponentProperty(t.name, 'TEXT', def);
      (refs.text[t.name] || []).forEach(function (n) { addRef(n, 'characters', id); });
    });
    (spec.booleans || []).forEach(function (b) {
      var id = set.addComponentProperty(b.name, 'BOOLEAN', !!b.default);
      (refs.bool[b.name] || []).forEach(function (n) { addRef(n, 'visible', id); });
    });
    propRefs.forEach(function (r, n) { n.componentPropertyReferences = r; });
    mark(set);
    if (set.type === 'COMPONENT_SET') {
      var kids = set.children.slice(), cols = Math.min(kids.length, (spec.axes && spec.axes.length > 1) ? spec.axes[spec.axes.length - 1].values.length : 4);
      var colW = 0, rowH = 0;
      kids.forEach(function (c) { colW = Math.max(colW, c.width); rowH = Math.max(rowH, c.height); });
      kids.forEach(function (c, i) { c.x = 32 + (i % cols) * (colW + 32); c.y = 32 + Math.floor(i / cols) * (rowH + 32); });
      var rows = Math.ceil(kids.length / cols);
      set.resizeWithoutConstraints(64 + cols * colW + (cols - 1) * 32, 64 + rows * rowH + (rows - 1) * 32);
      set.strokes = [{ type: 'SOLID', color: { r: 0.592, g: 0.278, b: 1 } }]; set.dashPattern = [6, 4]; set.strokeWeight = 1; set.cornerRadius = 8;
    }
    set.x = startX; set.y = 0;

    // 8. composición (ej. Stepper hecho de instancias de Stepper Step)
    var composed = null;
    var C = spec.composition || {};
    if (C.enabled) {
      log('Armando ' + C.name + '…');
      var defs = set.componentPropertyDefinitions || {};
      var keyOf = {};
      Object.keys(defs).forEach(function (k) { keyOf[k.split('#')[0]] = k; });
      composed = figma.createComponent(); made.push(composed);
      composed.name = C.name;
      composed.layoutMode = C.direction === 'column' ? 'VERTICAL' : 'HORIZONTAL';
      composed.primaryAxisSizingMode = 'AUTO'; composed.counterAxisSizingMode = 'AUTO';
      composed.fills = [];
      if (C.gap && V[C.gap]) composed.setBoundVariable('itemSpacing', V[C.gap]);
      C.items.forEach(function (it) {
        var want = {}; (it.variant || []).forEach(function (w) { want[w.axis] = w.value; });
        var target = set.type === 'COMPONENT_SET' ? set.children.filter(function (c) {
          return Object.keys(want).every(function (a) { return c.variantProperties && c.variantProperties[a] === want[a]; });
        })[0] || set.defaultVariant : set;
        var inst = target.createInstance();
        var props = {};
        (it.texts || []).forEach(function (t) { if (keyOf[t.prop]) props[keyOf[t.prop]] = t.value; });
        if (Object.keys(props).length) inst.setProperties(props);
        composed.appendChild(inst);
      });
      composed.description = C.description || ('Composición de ' + spec.name + '.');
      page.appendChild(composed);
      composed.setSharedPluginData('dscopilot', MARK, C.name + '·' + spec.name);
      created.push(composed.id);
      composed.x = startX; composed.y = set.y + set.height + 80;
    }

    await figma.setCurrentPageAsync(page);
    figma.viewport.scrollAndZoomIntoView(composed ? [set, composed] : [set]);
    return { setId: set.id, composedId: composed ? composed.id : null, warnings: warnings, componentTokens: compPlan ? Object.keys(CT).length : 0, page: page.name };
  }

  async function build(spec, log) {
    var made = [];
    try { return await buildInner(spec, log, made); }
    catch (e) {
      for (var i = made.length - 1; i >= 0; i--) { try { if (!made[i].removed) made[i].remove(); } catch (err) { /* ya no existe */ } }
      throw new Error((e && e.message || e) + ' · Deshice lo que se había creado: el archivo quedó como estaba.');
    }
  }

  // ---- verificación: se relee lo construido y se compara con lo aprobado
  async function verify(spec, out, sys) {
    var checks = [];
    function check(label, problems) { checks.push({ label: label, ok: !problems.length, problems: problems.slice(0, 8) }); }
    var set = await figma.getNodeByIdAsync(out.setId);
    if (!set) { check('El componente existe en el archivo', ['No lo encontré después de construirlo']); return checks; }
    var variants = SPEC.combos(spec.axes);
    var vnodes = set.type === 'COMPONENT_SET' ? set.children : [set];
    var p1 = [];
    if (vnodes.length !== variants.length) p1.push('Esperaba ' + variants.length + ' variantes y hay ' + vnodes.length);
    check(variants.length + (variants.length === 1 ? ' variante' : ' variantes') + ', con las propiedades aprobadas', p1.concat(
      (spec.texts || []).concat(spec.booleans || []).filter(function (p) { return !Object.keys(set.componentPropertyDefinitions || {}).some(function (k) { return k.split('#')[0] === p.name; }); })
        .map(function (p) { return 'Falta la propiedad ' + p.name; })));

    var unbound = [], wrongStyle = [], low = [];
    async function nameOf(alias) { if (!alias) return null; var v = await figma.variables.getVariableByIdAsync(alias.id); return v ? v.name : null; }
    for (var i = 0; i < vnodes.length; i++) {
      var vn = vnodes[i];
      var all = [vn].concat(vn.findAll(function () { return true; }));
      for (var j = 0; j < all.length; j++) {
        var n = all[j];
        if (n.type === 'INSTANCE' || (n.parent && n.parent.type === 'INSTANCE')) continue;
        var paints = [].concat(n.fills && n.fills.length ? n.fills : [], n.strokes && n.strokes.length ? n.strokes : []);
        paints.forEach(function (p) { if (p.type === 'SOLID' && !(p.boundVariables && p.boundVariables.color)) unbound.push(vn.name + ' · ' + n.name); });
        if (n.type === 'TEXT') {
          var L = (spec.layers || []).filter(function (l) { return l.name === n.name; })[0];
          var st = typeof n.textStyleId === 'string' && n.textStyleId ? await figma.getStyleByIdAsync(n.textStyleId) : null;
          if (L && (!st || st.name !== L.textStyle)) wrongStyle.push(vn.name + ' · ' + n.name + ': ' + (st ? st.name : 'sin Text Style'));
        }
      }
    }
    check('Todos los colores atados a tokens', unbound);
    check('Textos con el Text Style aprobado', wrongStyle);

    // contraste sobre los valores reales del archivo (claro y oscuro)
    var report = SPEC.validate(spec, sys);
    check('Contraste medido en claro y oscuro', report.errors.filter(function (e) { return /:1, necesita/.test(e); }));
    if (out.componentTokens) check(out.componentTokens + ' tokens de componente apuntando a semánticos y espaciados del sistema', []);
    return checks;
  }

  return { readSystem: readSystem, build: build, verify: verify };
})();

// ---------------------------------------------------------------------------
// Plugin
// ---------------------------------------------------------------------------
if (typeof figma !== 'undefined') {
  figma.showUI(__html__, { width: 420, height: 680, themeColors: true });
  (async function () {
    var saved = await figma.clientStorage.getAsync('diagnosis');
    var key = await figma.clientStorage.getAsync('apiKey');
    var session = await figma.clientStorage.getAsync('session');
    var compSession = await figma.clientStorage.getAsync('compSession');
    var colls = await figma.variables.getLocalVariableCollectionsAsync();
    var existingNow = await collectExisting();
    existingNow.components = figma.currentPage.findAllWithCriteria({ types: ['COMPONENT_SET', 'COMPONENT'] })
      .filter(function (n) { return n.type === 'COMPONENT_SET' || !n.parent || n.parent.type !== 'COMPONENT_SET'; }).length;
    existingNow.collectionNames = colls.map(function (c) { return c.name; });
    figma.ui.postMessage({
      existing: existingNow, selection: figma.currentPage.selection.length,
      type: 'init', fileName: figma.root.name, pageName: figma.currentPage.name, pages: figma.root.children.length,
      hasKey: !!key, model: (await figma.clientStorage.getAsync('model')) || null,
      saved: saved ? { fileName: saved.fileName, date: saved.date, result: saved.result } : null,
      session: session || null,
      compSession: compSession || null,
      emptyFile: figma.root.children.length === 1 && figma.currentPage.children.length === 0 && colls.length === 0,
      hasSystem: colls.length > 0,
      hasOurCollections: colls.some(function (c) { return c.name === COLLECTIONS.primitives || c.name === COLLECTIONS.semantic; })
    });
  })();

  function postSelection() { figma.ui.postMessage({ type: 'selection', count: figma.currentPage.selection.length }); }
  figma.on('selectionchange', postSelection);
  figma.on('currentpagechange', postSelection);
  figma.ui.onmessage = async function (msg) {
    if (msg.type === 'analyze') {
      try {
        var t0 = Date.now();
        var result = await run(msg.scope);
        result.ms = Date.now() - t0;
        result.scope = msg.scope;
        await figma.clientStorage.setAsync('diagnosis', { fileName: figma.root.name, date: new Date().toISOString(), result: result });
        figma.ui.postMessage({ type: 'result', result: result });
      } catch (e) {
        figma.ui.postMessage({ type: 'error', text: String(e && e.message || e) });
      }
    } else if (msg.type === 'getKey') {
      figma.ui.postMessage({ type: 'key', key: await figma.clientStorage.getAsync('apiKey') || '', reqId: msg.reqId });
    } else if (msg.type === 'setKey') {
      await figma.clientStorage.setAsync('apiKey', msg.key);
      if (msg.model) await figma.clientStorage.setAsync('model', msg.model);
    } else if (msg.type === 'saveSession') {
      await figma.clientStorage.setAsync('session', msg.session);
    } else if (msg.type === 'clearSession') {
      await figma.clientStorage.deleteAsync('session');
    } else if (msg.type === 'validate') {
      figma.ui.postMessage({ type: 'validated', reqId: msg.reqId, report: validateStep(msg.step, msg.proposal) });
    } else if (msg.type === 'build') {
      try {
        var out = await build(msg.plan, function (t) { figma.ui.postMessage({ type: 'buildProgress', text: t }); });
        figma.ui.postMessage({ type: 'buildProgress', text: 'Verificando lo construido contra lo aprobado…' });
        var checks = await verify(msg.plan);
        var fpage = await figma.getNodeByIdAsync(out.pageId);
        await figma.setCurrentPageAsync(fpage);
        figma.viewport.scrollAndZoomIntoView(fpage.children);
        figma.ui.postMessage({ type: 'built', warnings: out.warnings, checks: checks });
      } catch (e) {
        figma.ui.postMessage({ type: 'buildError', text: String(e && e.message || e) });
      }
    } else if (msg.type === 'saveCompSession') {
      await figma.clientStorage.setAsync('compSession', msg.session);
    } else if (msg.type === 'readSystem') {
      figma.ui.postMessage({ type: 'system', reqId: msg.reqId, system: await readSystem() });
    } else if (msg.type === 'validateComp') {
      figma.ui.postMessage({ type: 'validated', reqId: msg.reqId, report: validateComponentStep(msg.step, msg.proposal, msg.sys) });
    } else if (msg.type === 'buildComp') {
      try {
        var cout = await buildComponents(msg.plan, function (t) { figma.ui.postMessage({ type: 'buildProgress', text: t }); });
        figma.ui.postMessage({ type: 'buildProgress', text: 'Verificando los componentes contra lo aprobado…' });
        var cchecks = await verifyComponents(msg.plan);
        figma.ui.postMessage({ type: 'builtComp', warnings: cout.warnings, checks: cchecks });
      } catch (e) {
        figma.ui.postMessage({ type: 'buildError', text: String(e && e.message || e) });
      }
    } else if (msg.type === 'select') {
      var nodes = [];
      for (var i = 0; i < msg.ids.length; i++) {
        var n = await figma.getNodeByIdAsync(msg.ids[i]);
        if (n && n.type !== 'PAGE' && n.type !== 'DOCUMENT') nodes.push(n);
      }
      if (!nodes.length) return;
      var page = nodes[0];
      while (page && page.type !== 'PAGE') page = page.parent;
      if (page && page !== figma.currentPage) await figma.setCurrentPageAsync(page);
      nodes = nodes.filter(function (n) { var q = n; while (q && q.type !== 'PAGE') q = q.parent; return q === page; });
      figma.currentPage.selection = nodes;
      figma.viewport.scrollAndZoomIntoView(nodes);
      figma.ui.postMessage({ type: 'selected', count: nodes.length });
    } else if (msg.type === 'readCustomSystem') {
      try { figma.ui.postMessage({ type: 'customSystem', reqId: msg.reqId, system: await CUSTOM.readSystem() }); }
      catch (e) { figma.ui.postMessage({ type: 'customSystem', reqId: msg.reqId, system: null }); }
    } else if (msg.type === 'saveCustomSession') {
      await figma.clientStorage.setAsync('customSession', msg.session);
    } else if (msg.type === 'buildCustom') {
      try {
        var cu = await CUSTOM.build(msg.spec, function (t) { figma.ui.postMessage({ type: 'customProgress', text: t }); });
        figma.ui.postMessage({ type: 'customProgress', text: 'Verificando lo construido contra lo aprobado…' });
        var cuChecks = await CUSTOM.verify(msg.spec, cu, msg.sys);
        figma.ui.postMessage({ type: 'customBuilt', checks: cuChecks, warnings: cu.warnings, page: cu.page });
      } catch (e) {
        figma.ui.postMessage({ type: 'customError', text: String(e && e.message || e) });
      }
    } else if (msg.type === 'docsScan') {
      try {
        var d = await DOCS.scan(msg.withImages);
        figma.ui.postMessage({ type: 'docsSnapshot', snapshot: d.snapshot, images: d.images });
      } catch (e) {
        figma.ui.postMessage({ type: 'docsError', text: String(e && e.message || e) });
      }
    } else if (msg.type === 'resize') {
      figma.ui.resize(msg.width, msg.height);
    }
  };
}

if (typeof module !== 'undefined') module.exports = { validateComponentStep: validateComponentStep, validateStep: validateStep, contrastPairs: contrastPairs, REQUIRED_SEMANTICS: REQUIRED_SEMANTICS, analyze: analyze, analyzeColors: analyzeColors, toOklab: toOklab, familyOf: familyOf, dist: dist, contrast: contrast };
